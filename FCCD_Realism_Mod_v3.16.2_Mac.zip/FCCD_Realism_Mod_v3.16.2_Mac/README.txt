FCCD Realism Mod v3.16.2 (Mac) - hotfix: old saves load again; error box ignores harmless notices
=============================================================
INSTALL: quit the game, replace app.asar only (new size 55,629,047 bytes).
coreWorker.js stays the v3.16 one (5,946,611 bytes); footballSimWorker.js unchanged.

FIX: the Load Game screen went blank. Any save sitting at the last offseason week
under the game's original calendar (made before the mod's calendar change in v3.8)
asked for "week 35", which the mod's calendar doesn't have, and that one save
crashed the whole Load screen. Week numbers past the end now count as Advance Year
(the step those saves were on), so the list shows and the save can advance.
Also new: if the screen ever goes blank again, a red error box appears at the top
with the error text - send a screenshot of it.

FCCD Realism Mod v3.16 (Mac) - for Andrew's Wisconsin dynasty
=============================================================
INSTALL (two files this time):
 1. Quit the game. Football Coach.app > Show Package Contents > Contents/Resources/
 2. Replace app.asar (new size 55,627,748 bytes).
 3. Replace app.asar.unpacked/dist/main/coreWorker.js (new size 5,946,611 bytes).
    footballSimWorker.js is unchanged. Everything from v3.15 and earlier is still included.

NEW IN v3.16 - Money drives everything (on by default; needs NIL turned on)
Game Settings > League > "Money drives everything" (off = the game's own NIL).
 1. Real budgets. Every school's yearly NIL budget comes from its real 2026
    football money (The Athletic budgets for the Power 4 + Notre Dame, The Sideline
    for everyone else; Army/Navy/Air Force $5.4M), at the game's money scale (half
    the real dollars): Ohio State $25.75M, Texas $25M, Wisconsin $14.5M,
    Louisville $11.75M, Boise State $4.65M, Kent State $1.4M. The prestige-based
    NIL cap no longer applies.
 2. Computer-run schools now have to stay within their budget. In the stock game
    they recruited as if they had $100M, so a MAC school offered a 5-star the same
    NIL as Ohio State. Now every school's offers count against its budget (75% of
    it during the season, all of it in the offseason), and rich schools bid more
    per player (up to 1.6x market value) while poor ones bid less (down to 0.5x).
    The same applies to transfers in the portal.
 3. NIL matters more to recruits: an offer at market value is worth about a third
    more recruiting points than before.
 4. Rich collectives keep their players: at a big-money school up to about a third
    of players who want to transfer are paid to stay. Poor schools get their good
    starters (76+ OVR) bought away by bigger NIL offers. (Your own team keeps the
    game's normal rules: you decide who to pay to stay.)
 5. Donor momentum. Each offseason a school's money moves with how its season went
    against expectations: winning, titles and playoff runs raise giving (up to
    160% of the school's base over several good years), losing lowers it (down to
    60%). Half of any unspent NIL carries over, plus a small share of TV/booster
    money, so moving to a richer conference helps a little.
 6. Prestige follows the money. Each offseason, after the normal win/loss change,
    prestige moves 12% of the way toward the level the school's money buys
    ($47M+ real = 10, $40M = 9, $31M = 8, $24M = 7, $18M = 6, $12M = 5, $7M = 4,
    $5.5M = 3, $4M = 2). Over several years well-funded schools rise and
    underfunded ones slide, unless results keep them up. Expectations, recruiting
    and the coaching carousel follow prestige.
 7. Newspaper: a one-time "NIL era" story when the mod takes over, then an
    offseason Money Report (biggest budgets, hot and cold donors, schools moving
    up or down) plus a Wisconsin budget story.
 8. 2001 transfer rules (v3.15) are now OFF by default, since 2001 had no NIL. You
    can still switch them back on in Game Settings.
On your current save: budgets switch to money the first time you open the week's
schedule after installing; donor momentum and prestige drift start this offseason.
Tested in a sandbox on the real game code (not yet inside the Mac game).

FCCD Realism Mod v3.15 (Mac) - for Andrew's Wisconsin dynasty
=============================================================
Install exactly like v3.14: replace app.asar (55,618,018 bytes). coreWorker.js and
footballSimWorker.js are unchanged. Everything from v3.14 and earlier is still included.

NEW IN v3.15 - 2001 transfer rules (on by default, all teams incl. Wisconsin)
Game Settings > League > "2001 transfer rules" (off = the game's own portal).
 1. Sit-out year: every player who changes schools sits out his first season at
    the new school. He shows on the injury report as "Sitting out (transfer)"
    (ratings unchanged), practices, and plays the next year. If he hasn't
    redshirted, the sit-out year becomes his redshirt (the game does this
    automatically for players with 0 games). 2% get a hardship waiver.
 2. 2001 volume: about 600-650 players a year leave (4-5 per team), mostly
    backups and freshmen/sophomores; starters rarely, 80+ starters almost never.
    The mod checks the count every offseason and nudges it toward 650.
 3. Dropping down: many leavers go to I-AA or junior college (they leave the
    league) so about 40% land at another FBS school; self-adjusting each year.
 4. Permission to contact: 85% of transfers can't sign with a conference rival.
 5. Following a coach is 4x rarer, and those players sit too.
 6. Newspaper: offseason "Transfer report" and preseason "Year in residence"
    story listing who sits (plus a Wisconsin-specific story).
Applies from the next offseason on an existing save. Tested in a sandbox on the
real game code and your universe rosters (not yet inside the Mac game).

FCCD Realism Mod v3.14 (Mac) - for Andrew's Wisconsin dynasty
=============================================================
Built for the Mac Steam build of Football Coach: College Dynasty
(stock app.asar 55,934,367 bytes). Re-apply after every FCCD update.
Everything from v3.13, v3.12, v3.11.1, v3.10 and v3.9 is still included.
Only app.asar changed (coreWorker.js and footballSimWorker.js are the same
as v3.11.1, included so all three files match).

NEW IN v3.14
 1. Turn off conference title games (any playoff format).
    Game Settings > League > "CCG format" > "No conference title games".
    - No conference championship games are scheduled.
    - Each conference champion comes from the standings: best conference
      record; ties go to head-to-head among the tied teams (only if they
      all played each other), then record against common conference
      opponents, then the committee ranking. With three or more tied, the
      steps start over each time the group gets smaller.
    - The champion is the official conference champion everywhere: title
      history, automatic playoff bids, the poll bonus, and its head coach's
      championship count (which feeds the Coach Pedigree recruiting bonus).
    - Committee rankings: a standings champion gets a smaller bump than a
      title-game winner used to (0.5 instead of 0.8).
    - Notre Dame is never ACC champion; UConn is independent.
    - With the stock 12-team formats, week 14 becomes an open week
      ("Open Week (no CCGs)"); Army-Navy and the Heisman stay in week 15,
      and the playoff still starts in week 16.
    - Change it in any offseason or preseason (locked during the season).
    The 24-team playoff always plays without title games.
    Per conference: Customization > "Change postseason locations" > set a
    conference's CCG location to "No title game". That conference crowns
    its champion from the standings (same tiebreakers and credit as above)
    while the others still play their title games.

 2. 24-team playoff, real 2027 format (reported by On3, Oct 15 2026).
    - Automatic bids: the 4 Power 4 conference champions (SEC, Big Ten,
      Big 12, ACC by conference prestige) and the best-ranked Group of 6
      champion. The other 19 spots go to the highest-ranked teams.
    - A champion ranked below the cutoff still gets in; the lowest at-large
      team drops out.
    - Seeds 1-24 strictly by ranking (champions are not moved up). Top 8
      get byes.
    - New calendar:
        week 13  last regular-season games; the field is set
        week 14  Army-Navy (Philadelphia) and the Heisman / awards
        week 15  first round on campus (9 v 24, 16 v 17, ...)
        week 16  second round on the campuses of seeds 1-8
        week 17  quarterfinals at New Year's Six bowls (Rose always one)
        week 18  semifinals
        week 19  national championship
      Week names in the game follow it ("Army-Navy & Awards",
      "CFP First Round"), and the award ceremony screen opens before the
      first round.
    - The dynasty's first season still uses the 12-team format (with title
      games); the 24-team format starts in season two.

 3. Conference schedules: no more than 2 conference home games (or 2 road
    games) in a row. The game now arranges which week each conference game
    is played in so homes and roads alternate. Who hosts each game doesn't
    change (home-and-home series still alternate every year), traditional
    dates stay put (Red River, Florida-Georgia in Jacksonville, Third
    Saturday, rivalry week), and there are still no byes after week 10.
    Tested on your universe file over 10 seasons, wherever the mod's own
    scheduler builds the conference schedule (every conference with the
    "Early games" non-conference setting, and the SEC, Big Ten, Big 12, ACC,
    American and MAC with any setting): team-seasons with a 3+ game home or
    road stretch went from 1,483 to 2 (out of 2,320). With other settings
    the Pac-12, Mountain West and Conference USA use the game's own
    round-robin, where about 1 team per conference still gets one 3-game
    stretch (it was about 7). Starts with the next schedule the game builds (2027 on
    your current save).

 4. BCS rankings (throwback mode), on/off.
    Game Settings > League > "BCS rankings". Off by default.
    - From week 8 through the final standings, the official ranking is the
      BCS standings: (Harris poll % + Coaches poll % + computer %) / 3, the
      2004-2013 formula. Before week 8 (and after the final standings) the
      human poll is the ranking.
    - Human polls: the mod's AP-style poll now runs all season with its own
      week-to-week memory (losses drop a team 3-9 spots, winners hold,
      newcomers climb slowly). Harris (114 voters) and Coaches (59 voters)
      ballots are drawn around it, so the two polls differ slightly, and
      each team gets its share of the maximum points, like the real ones.
    - Computers: six win-loss-only rankings (no margin of victory, as
      required from 2002 on), each ranking's top 25 scored 25-1, highest and
      lowest thrown out, the other four summed out of 100:
        Colley Matrix (the published method), Wolfe (Bradley-Terry maximum
        likelihood), Sagarin ELO-chess style, Massey (win-loss least
        squares), Anderson & Hester style (record + opponents' and
        opponents' opponents' records) and Billingsley style (starts from
        the preseason order and moves week by week). Colley and Wolfe follow
        their published methods; the other four are close approximations,
        since those formulas were never fully published. FCS opponents
        count as one pooled team, as in the Colley Matrix.
    - The BCS standings pick and seed the field in whatever playoff format
      you use. For a classic BCS season, pair it with "Single game (no
      playoff)" (#1 vs #2). Bowl matchups come from your universe file's
      bowl list and tie-ins, so a throwback file can list the Rose, Sugar,
      Orange and Fiesta Bowls first with their conference tie-ins.
    - The committee rankings are switched off while it's on. Each week the
      newspaper runs the BCS standings (top 25 with the BCS average), and the
      last one is "Final BCS standings".
    - Turn it on or off in any offseason; it applies from the next week.

 Wisconsin and the "10 Power 4 games" idea: Wisconsin plays 9 Big Ten games,
 and the mod's scheduler (from v3.10) gives every Power 4 team one Power 4
 non-conference game, so Wisconsin gets about 10 a season (Northern Illinois
 every other year is extra).

 Works on your current save. For the 24-team playoff and the title-game
 switch, change the settings in the offseason.

FROM v3.13 (still included): AP-style media poll for Weeks 0-8 (from the real 2025 and
2026 AP polls; the committee still takes over from Week 9)
 1. Last week's poll carries over through Week 8 (never less than 35%;
    before, it faded to nothing by Week 7).
 2. Winners hold: a ranked team that doesn't lose drops at most 2 spots.
 3. Losses drop like the AP: a ranked team that loses falls 3-9 spots
    (2-6 if the loss was to a top-10 team); a team ranked 21-25 that loses
    to anyone outside the top 10 falls out.
 4. Newcomers (teams not in the preseason top 25) enter no higher than #17
    and climb at most 4 spots a week.
 5. Pedigree: through Week 8, a preseason top-10 team with no more than
    one loss that keeps winning isn't passed by a newcomer it was ahead of.
 The preseason poll is unchanged (it still matches the real AP top 25).
 Works on your current save; it starts with next week's poll.

FROM v3.12 (still included): committee rankings rebuilt from the 2024 and 2025 CFP rankings
 1. Effective losses. Each loss is weighed by who it came against (top 5:
    0.6, top 10: 0.7, top 25: 0.85, unranked: 1.0, outside the top 60 or
    FCS: 1.25), a little less on the road, and early losses fade (a loss
    10+ weeks old counts 35% less). A conference title game loss counts
    0.2 (Ohio State 2025, Texas/Penn State 2024 dropped about one spot).
 2. Graded wins: top 5 counts 2, top 10 1.5, top 25 1, ranks 26-40 0.4.
 3. Conference champions get a modest bump (Georgia 2024 went 5 to 2).
 4. Head-to-head and common opponents only decide between teams with about
    the same effective record (Miami over Notre Dame 2025). Beating a team
    doesn't keep you above it when your record is clearly worse (Alabama
    and Ole Miss both beat Georgia in 2024; Georgia was #2).
 5. Records first, from Week 9: a clearly better effective record moves a
    team ahead unless the other team's schedule was much tougher, or it
    won head-to-head AND had a tougher schedule with less than a 1.5-loss
    gap (Texas 9-3 over Vanderbilt 10-2, 2025). A strong schedule can
    outweigh one extra loss, rarely two (Alabama 10-3 in the 2025 field).
 6. Group of 5 lane: Group of 5 teams take a ranking discount, never pass a
    Power 4 team on record alone, and rank behind a Power 4 team with a
    much tougher schedule and no more than one extra effective loss
    (Boise State 12-1 was #9, James Madison 12-1 #24).
 7. Sticky rankings (from Week 10): a top-25 team that wins drops at most
    two spots in a week.
 8. Margin and yardage count about a third less (dominance still matters).
 9. Four-loss teams: still no at-large bid, unless the team has 3+ wins over
    top-10 teams.
10. Playoff field ("4 conference champs + 8 at-large" format): the Group of 5
    automatic bid now goes to the best-ranked Group of 5 CONFERENCE CHAMPION
    (UConn still excluded), and a Group of 5 team needs a top-12 ranking for
    an at-large spot.
 Not added: player availability (the committee ignored Georgia's QB injury
 in 2024, so only something as extreme as FSU 2023 would apply).
 Works on your current save; the stickiness rule starts after one week of
 rankings are stored.

FROM v3.11 (still included)
 A. Eight new coaching badges. Game Management finally has badges.
    - Ice in the Veins (Game Mgmt): +2 to all attributes in one-score
      games (8 or fewer) in the last 5 minutes and in overtime.
    - Halftime Adjuster (Game Mgmt): +2 to all attributes in the 3rd
      quarter when trailing.
    - Big Game Coach (Game Mgmt): +1 to all attributes against ranked
      opponents and in rivalry, bowl and playoff games.
    - Road Warrior (Game Mgmt): on the road, the home team's home-field
      advantage is cut in half.
    - Turnover Machine (Defense): defenders +4 Catching (interceptions),
      opposing ball carriers -4 Ball Security (fumbles).
    - Red Zone Maestro (Offense): +2 to all offensive attributes inside
      the opponent's 20.
    - Culture Builder (Training): 25% fewer of his players transfer out.
    - Portal King (Recruiting): +100 points on pitches to transfers.
    Who can earn them: Game Management = every archetype except Offensive
    CEO and Defensive CEO; the others follow their category.
 B. Existing coaches get the new badges (one time, the first time you load
    or advance your save after installing). Each existing badge has the same
    chance of being swapped for a new one that it would have had if the new
    badges had been in the game from the start. Badge counts don't change.
 C. Signature badges (a bonus slot that doesn't count against the badges a
    coach earns by level): Culture Builder - Dabo Swinney, Curt Cignetti,
    Kirk Ferentz, P. J. Fleck, Kalani Sitake, Matt Campbell, Kyle
    Whittingham, Jeff Monken, Clark Lea. Portal King - Lane Kiffin, Deion
    Sanders, Rhett Lashlee, Joey McGuire. Big Game Coach - Kirby Smart,
    Ryan Day, Marcus Freeman, Kalen DeBoer. Red Zone Maestro - Lincoln
    Riley, Steve Sarkisian, Josh Heupel. Halftime Adjuster - Bill
    Belichick. Ice in the Veins - Pat Fitzgerald. Wisconsin's staff gets
    no signature badge.
 D. The "Cignetti hire" (CPU teams only). When a down program (prestige 6
    or lower that had a losing season, or any prestige 4 or lower) hires a
    proven winner moving up (5+ years as a head coach, .650+ win pct, a
    conference or national title or .720+, level 18+, from a smaller school,
    out of work, or from FCS), there is a 35% chance he becomes a program
    changer. At most one every 4 seasons; expect one about every 4-7
    seasons. For his first three seasons at that school: +1 recruiting,
    +1 training and +1 to his side's playcalling; players develop faster
    (+4 training); 35% fewer players transfer out; transfers see the school
    as 2 prestige levels higher (high schoolers 1) and pitches get bonus
    points; more of his old players follow him (up to 16). No hidden game
    boost and no free prestige: the team still has to win. It's hidden:
    the newspaper only asks "Can he do it again?" and runs a TURNAROUND
    story if year one jumps by 4+ wins.
 E. Coaches move to and from FCS. Each offseason 1-3 proven FCS head
    coaches (real FCS school names, 5-12 seasons, winning records,
    conference and sometimes FCS national titles) enter the hiring pool;
    their coach page shows "Former FCS HC: ..." and their record counts
    (slightly discounted) in the carousel. A few out-of-work FBS coaches
    who went unhired take FCS jobs (shown as retired, with "At FCS ...")
    and can come back a few years later through the comeback rolls.
 F. Recruit dealbreakers (new recruiting classes from now on, plus all
    transfers). About 70% of 5-stars, 55% of 4-stars, 12% of 3-stars and
    40% of 4/5-star transfers rule out schools outright, based on what they
    care about most: prestige (5-star with A potential: 8+; other 5-stars
    7+; 4-stars 5-6+; transfers 5+), distance (about 550 miles), playing
    time (won't sign where he'd be buried) or academics. Shown on the
    recruit page in orange ("Dealbreaker: ..."). Interest at a school that
    breaks it is 0 and he will not sign there.
 G. Hometown Hero. In-state 4- and 5-star recruits lean hard toward their
    state's flagship (+12 interest for the first school listed, +8 for the
    others; 3-stars +5/+3), and the flagship gets 2 levels of slack on a
    prestige dealbreaker. Flagships: AL Alabama, Auburn; AZ Arizona State,
    Arizona; AR Arkansas; CA USC, UCLA, Cal; CO Colorado; CT UConn;
    DE Delaware; FL Florida, Florida State, Miami; GA Georgia, Georgia
    Tech; HI Hawaii; ID Boise State; IL Illinois, Northwestern; IN Indiana,
    Purdue, Notre Dame; IA Iowa, Iowa State; KS Kansas State, Kansas;
    KY Kentucky, Louisville; LA LSU; MD Maryland; MA Boston College;
    MI Michigan, Michigan State; MN Minnesota; MS Ole Miss, Mississippi
    State; MO Missouri; NE Nebraska; NV UNLV, Nevada; NJ Rutgers; NM New
    Mexico; NY Syracuse; NC North Carolina, NC State; ND North Dakota
    State; OH Ohio State; OK Oklahoma, Oklahoma State; OR Oregon, Oregon
    State; PA Penn State, Pittsburgh; SC South Carolina, Clemson;
    TN Tennessee; TX Texas, Texas A&M; UT Utah, BYU; VA Virginia Tech,
    Virginia; WA Washington, Washington State; WV West Virginia;
    WI Wisconsin; WY Wyoming.
 H. Recruiting logic:
    - Early commits: 3-stars who care most about playing time or being
      close to home commit about 30% sooner; 4-stars wait 10% longer,
      5-stars 20% longer.
    - Flips: in weeks 9-13, a committed 4/5-star can flip to a school that
      offered him and now beats his school's interest by 15+ points (1.5-5%
      a week, at most 6 flips a week league-wide; half as likely when your
      team is involved).
    - Blue-blood focus: CPU prestige 9-10 teams aim at the top 300 recruits;
      CPU prestige 5-and-below teams stop chasing top-60 recruits.
    - Signing day: unsigned 4/5-star high schoolers sign with the CPU team
      with room that interests them most instead of going unsigned.
 I. Suspensions and academic eligibility (all teams, Wisconsin included).
    After Week 0 about 1 in 3 teams has a player suspended 1-3 games and
    about 1 in 7 loses a player to academics (75% first half of the season,
    25% the whole season). During the season about 3% of teams per week
    suspend a player for one game. About 70% are backups. Players show as
    "Suspended" / "Academically ineligible" on the injury report (ratings
    unchanged), sit out like a severe injury, and every case is in the
    newspaper.
 J. UConn is an independent: never in the Pac-12 title game, never Pac-12
    champion (24-team format too), and not eligible for the Group of 5
    automatic playoff bid (it can still be an at-large team).

(stock app.asar 55,934,367 bytes). Re-apply after every FCCD update.

FROM v3.10 (still included)
 A. Real 2026 schedule (NEW save starting in 2026). Every FBS game from
    the real 2026 schedule, in the real weeks (including Week 0), with the
    real neutral sites: Wisconsin vs Notre Dame at Lambeau Field, Texas-
    Oklahoma at the Cotton Bowl, Florida-Georgia in Atlanta, Baylor-Auburn
    (Aflac Kickoff), Louisville-Ole Miss in Nashville, UNC-TCU in Dublin,
    Arizona State-Kansas at Wembley, West Virginia-Virginia in Charlotte,
    Navy-Notre Dame at Gillette Stadium, Army-Navy Dec 12 at MetLife.
    - The Pac-12's undecided final-week "flex" games are filled with
      nearby conference rematches.
    - The game's 40 FCS teams now carry real FCS names and colors (South
      Dakota State, Montana, North Dakota, UC Davis, Villanova and more).
      The real schedule has about 100 FCS opponents, so lesser-known ones
      are played by the nearest of the 40.
    - If the universe's team list doesn't match the real one, the game
      quietly falls back to its own generated schedule.
 B. No byes after Week 10 on every schedule the game builds (2027 on).
    Tested on 6 seasons x 4 OOC settings: 0 late byes. (Exception: in the
    "early games" setting Army and Navy rest the week before Army-Navy.)
 C. Real stadium and town names. The game tooltip shows the stadium
    (e.g. "Camp Randall Stadium · Madison, WI"); College GameDay and Big
    Noon Kickoff now go to the town ("GameDay heads to Madison").
 D. Rivalry names and trophies (104 rivalries). Games are named (Paul
    Bunyan's Axe, Iron Bowl, The Game, Apple Cup, Red River Rivalry...)
    and the newspaper reports who keeps, claims or takes back each trophy.
 E. Playoff: the New Year's Six bowls host the quarterfinals in every
    playoff format, and the Rose Bowl is always a quarterfinal. Semifinals
    rotate (2026 Orange/Sugar, 2027 Orange/Cotton, then Fiesta/Peach...).
    Title game: Las Vegas 2026 season, New Orleans 2027, then rotates.
 F. Playoff selection show reveals #1 first and counts down to #25.
 G. Two-minute timeout: the clock stops at 2:00 of each half (before the
    snap, or right after a play that crosses 2:00). Shows in the play log.
 H. Struggling QBs get benched: in the second half, unless his team leads
    by 10+, a starter with 3 INTs, 2 INTs on under 50% passing, or under
    40% passing with under 4.5 yards per attempt gives way to the backup.
 I. Backups play in blowouts for every team, user or CPU, whether the
    team is way ahead OR way behind (4 points past your bench setting),
    and in third quarters decided by 45+.
 J. Heisman: run-first QBs (service-academy triple option) score lower:
    their rushing counts 70% and heavy run share is discounted. A passer
    with big numbers now beats an option QB with similar stats.
 K. Hot seat scores (0-10) for every head coach, updated weekly. Shown
    on the coach page header ("Hot seat 7.4/10 (Hot)"), in a weekly "Hot
    Seat Watch" ranking, and as a warning if you're in trouble.
 L. Rumor Mill in the newspaper (up to 3 a week). Rumors use the same
    dice rolls the game uses later, so they usually come true:
    coaches on the hot seat, NFL interest, coaches weighing retirement,
    former coaches (and NFL coaches) wanting back in, rising coaches
    drawing interest, and starters unhappy enough to transfer (your team
    is always checked).
 M. Coaches who leave for the NFL get an "NFL BOUND" story and "Left for
    the NFL" on their coach page; coaches coming back get "BACK FROM THE
    NFL" and "Returned from the NFL".
 N. First-year head coaches won't leave: no NFL departure, no retirement,
    and other schools can't hire them away (unless they're being fired).
 O. Internal promotion: when you hire a coordinator, assistants already
    on your staff are listed first and labeled "Internal promotion (your
    staff)". They're a bit more experienced than before (ages 33-52).
 P. Coach badges filled in for every coach to match their level (imported
    coaches had none). Existing saves get filled once when you next
    advance. Max limits unchanged (6 badges at level 25+).
 Q. Your team's AD opinion starts at the universe file's number (Wisconsin
    25) instead of always 50. NEW save needed.
 R. Unhappy starters can transfer: stars at lesser programs who want a
    bigger stage, starters on losing teams, and a few unhappy with their
    role. Loyal players never do; your own players are less likely.
 S. Smarter CPU recruiting: CPU teams target positions where they're thin
    and spread their targets across positions instead of stacking.
 T. Team page > History tab now shows "Program History": real all-time
    record, national title years and Heisman winners before the dynasty,
    and the national championship trophy count includes real titles.

 U. Future schedules (2027 on): Power 4 teams generally play only one
    non-conference Power 4 opponent; the rest of their non-conference
    games are against Group of 5 and FCS teams (Power 4 team at home).
    Named rivalries (Florida-FSU, Clemson-South Carolina, Iowa-Iowa State,
    etc.) are always kept, so a few teams play two.
 V. Rose Bowl and UCLA use Pasadena (91103). Title game in Los Angeles
    is at SoFi Stadium.

W. Committee-style rankings following the CFP selection committee
    protocol. Light influence from week 4; from the committee's first
    ranking after week 9 the committee ranking IS the ranking (it drives
    the Top 25, playoff selection and seeding), and each week's CFP top 25
    appears in the newspaper (final one on Selection Day): strength of schedule, record and quality of wins (wins over
    top-10/top-25 teams, bad losses to teams outside the top 60), and the
    statistical profile (point and yardage margin per game, capped so
    running up the score doesn't pay) adjust the
    poll; then closely ranked teams are re-ordered by head-to-head result,
    or by results against common opponents. Records come first (calibrated to the real 2024 and 2025 CFP
    rankings): a team with fewer losses ranks ahead unless the other team
    beat it or played a clearly tougher schedule, and a loss in a
    conference championship game counts only a quarter as much.
 Y. Bowl site picks like the real committee: the #1 seed takes the
    quarterfinal bowl nearest its campus, then #2 and #3; #4 gets the
    one left. The #1 seed's half of the bracket plays its semifinal at
    the semifinal bowl nearest the #1 seed.
 X. No at-large playoff bids for teams with 4 or more losses (a 4-loss
    conference champion still gets its automatic bid).

UNIVERSE FILE (2026_FBS_CFB27_RealNames_NoDivisions_Wk7_v310.json)
 - Rosters and coaching staffs: exactly the Week 7 file.
 - Prestige re-evaluated on the game's level counts (3 ten-star, 5 nine,
   7 eight, 10 seven, then 19/19/19/19/19/18).
 - Northwestern: new Ryan Field (stadium 8, facilities 10).
 - UCLA and the Rose Bowl moved to Pasadena 91103.

v3.11 works on your current save. Dealbreakers start with recruiting
classes created after you install it (transfers right away).
From v3.10, these need a NEW save: real 2026 schedule, AD opinion, FCS names.

FROM v3.9 (still included)
 1. Prestige-10 cushion: blue bloods start mid-level (needs NEW save)
 2. NFL early entry: star juniors usually declare; QBs and day-3
    prospects often return (NIL era)
 3. Hidden comeback boost for the user's team removed
 4. Transfers: stars favor big programs (v1), stars avoid weak
    programs, and a head coaching change triggers extra departures
 5. Coaching carousel: winning head coaches from smaller programs
    move up more often; coordinators less often
 6. Heisman/All-American: playing for a top team matters (v2)
 7. Coach retirement based on tenure: no retirements in a coach's first
    3 years at a school; long-tenured older coaches retire; bad seasons
    push older coaches out; coaches 70+ retire more often
 8. Coordinators (and occasionally head coaches) leave for the NFL.
    The game lists these departures as "retired".
 9. 2026 College Football Playoff format. To use it, choose the playoff
    format "4 conference champs + 8 at-large (no conference champ bye)"
    when creating the dynasty. With that format selected:
    - Auto bids: champions of the top 4 conferences (by conference
      prestige: SEC, Big Ten, Big 12, ACC), the highest-ranked team
      Group of 5 conference champion (v3.12), and Notre Dame if
      ranked in the top 12. Remaining spots go to the highest-ranked teams.
    - Seeds 1-12 strictly by final ranking; top 4 get byes.
    - First round (5v12, 6v11, 7v10, 8v9) on the higher seed's campus.
    - Quarterfinals/semifinals at the Rose, Sugar, Orange, Cotton,
      Fiesta and Peach Bowls on the 3-year semifinal rotation
      (2026 season: semis at Rose and Sugar).
    - National title game rotates host cities, starting in Las Vegas.
    - Notre Dame is never eligible for the ACC Championship Game under
      this format (it reaches the playoff through its top-12 auto bid).
10. Division-less conferences (2026 structure). Use the included universe
    2026_FBS_CFB27_RealNames_NoDivisions.json (this mod is REQUIRED to
    load it). SEC, Big Ten, Big 12, ACC, American and MAC have no
    divisions; Sun Belt keeps East/West. Every team plays 9 conference
    games: protected opponents every year (SEC: 3 each; Big Ten:
    official protected pairs) plus rotating opponents played
    home-and-home over two seasons. Top 2 in the standings play for the
    title. Georgia-Florida (Jacksonville) and Texas-Oklahoma (Dallas)
    are neutral-site games. Set Realignment to None.
11. Overtime (current NCAA rules): 1st OT possessions from the 25;
    2nd OT must go for two after a touchdown; 3rd OT and later are
    alternating two-point attempts only (no drives).
12. Traditional calendar. Choose the non-conference schedule setting
    "Early games" when creating the dynasty (it no longer means weeks
    1-4-7). With it:
    - Non-conference games in weeks 1-3, except Florida-Florida State,
      South Carolina-Clemson, Georgia-Georgia Tech and Kentucky-Louisville,
      which are played rivalry week (week 13).
    - Traditional dates: Red River (Dallas) week 6 in early October;
      Third Saturday in October (Alabama-Tennessee) week 7; Florida-Georgia
      (Jacksonville) week 9; Michigan-Michigan State and Kansas-Kansas
      State week 9; Alabama-LSU week 10 when scheduled; Cal-Stanford week 12;
      rivalry week (13): Iron Bowl, Egg Bowl, Texas-Texas A&M,
      Tennessee-Vanderbilt, Arkansas-Missouri, The Game, Minnesota-Wisconsin,
      Iowa-Nebraska, Indiana-Purdue, Illinois-Northwestern, Oregon-
      Washington, UCLA-USC, Penn State-Michigan State, Maryland-Rutgers,
      Iowa State-Kansas State, Territorial Cup, NC State-North Carolina,
      Virginia-Virginia Tech.
13. Postseason calendar (all settings): conference championships the
    week right after rivalry week (no empty week), then a bye week with
    the Heisman/awards and the Army-Navy Game (Philadelphia, a
    non-conference game; "Early games" setting), then the playoffs.

14. Group of 5 teams rarely host Power 4 teams (any schedule setting).
    In non-conference games between a Power 4 team and a Group of 5 team,
    the Group of 5 school hosts only if it is a strong program, based on
    its current prestige: prestige 6+ plays normal home-and-home series;
    prestige 5 hosts about one year in three of its turns (2-for-1 style);
    prestige 4 and below never hosts. Neutral-site games are unchanged.
    (Test: G5 home games vs P4 dropped from 48% to about 3.5%.)
15. Midseason firings (v3.9: your team is eligible too, see 21). From week 4
    through week 11, athletic directors may fire a head coach in his 2nd+
    season after a poor start for the program's prestige, a losing streak
    of 3+, an embarrassing loss (FCS, much weaker team, or 35+ point
    blowout), or a bad conference record. Hot-headed ADs and big programs
    act faster; laid-back ADs, long-tenured coaches and small programs less.
    An interim head coach (similar ratings, same schemes) runs the team
    for the rest of the year and is usually replaced in the carousel. The
    fired coach's contract is bought out and he joins the free-agent pool.
    Firings appear in the week's result message ("Coaching news: ...").
    About 8-9 midseason firings per season in testing (real 2025: ~11).
16. Real coaches join the free-agent pool over time (one-time entry each,
    random year, at the coach-leveling step of the offseason):
      - Jimbo Fisher (Ex-FSU/Texas A&M HC; out of coaching, wants back in; from 2026)
      - Brian Kelly (Ex-Notre Dame/LSU HC; taking 2026 off (Memphis consultant); from 2027)
      - Mike Gundy (Ex-Oklahoma State HC; ESPN analyst; from 2026)
      - Hugh Freeze (Ex-Ole Miss/Liberty/Auburn HC; unemployed; from 2026)
      - Ed Orgeron (Ex-LSU HC; linked to LSU openings; from 2026)
      - Jon Gruden (Ex-NFL HC (SB champ); says he wants an SEC head job; from 2026)
      - Sam Pittman (Ex-Arkansas HC; from 2026)
      - Mark Stoops (Ex-Kentucky HC; Texas special assistant; from 2026)
      - Urban Meyer (3x national champ; perennial comeback rumors; from 2026)
      - Bob Stoops (Ex-Oklahoma HC; came back once as interim; from 2026)
      - Chris Petersen (Ex-Boise State/Washington HC; from 2026)
      - Kliff Kingsbury (Ex-Texas Tech/Cardinals HC; NFL OC, frequently linked to college jobs; from 2026)
      - Mike McDaniel (Ex-Dolphins HC; Chargers OC; from 2027)
      - Brian Daboll (Ex-Giants HC; Titans OC; former Alabama OC; from 2027)
      - Sean McDermott (Ex-Bills HC; out of work; from 2026)
      - Jim Leonhard (Ex-Wisconsin DC/interim HC; NFL assistant; from 2027)
      - Jim Harbaugh (Chargers HC; ex-Michigan/Stanford HC; from 2028)
      - Mike Vrabel (Patriots HC; Ohio State alum, linked to OSU; from 2028)
      - Jeff Hafley (Dolphins HC; ex-Boston College HC; from 2028)
      - Todd Monken (Browns HC; ex-Southern Miss HC, ex-Georgia OC; from 2028)
    They can be hired as head coaches or coordinators by CPU teams. If a
    name already exists in your save, it is skipped.
17. Comebacks: coaches who retired or left for the NFL can return after
    sitting out 1-6 seasons. Better and younger coaches, and long-time
    head coaches, are more likely to come back; none return at 66+.
    Returning coaches skip retirement for their first offseason back.
18. Out-of-work head coaches with 3+ seasons as a head coach and level 18+
    are now real head-coaching candidates (before, the carousel almost
    never hired them). Sitting head coaches who are winning still rate
    a little higher.

NEW IN v3.9 (all work on your current save unless noted)
19. Coordinator jobs: high-level coaches won't take lower-level
    coordinator jobs. Sitting head coaches only become coordinators at
    top-25 programs (and only as a big step up); out-of-work head coaches
    (3+ seasons) and level-24+ coaches only take coordinator jobs at
    top-40 programs; level-22+ coordinators only at top-70 programs.
    (If a school would be left with fewer than 3 candidates, the rule
    is relaxed for that hire.)
20. Coaches who "took a break" get major jobs. Out-of-work head coaches
    with 5+ seasons and a winning record get a proven-winner bonus based
    on career win %, national titles, conference titles and playoff
    wins. Test: a Jimbo Fisher-type (128-48, 1 title) now outscores a hot
    Group of 5 coach and a sitting Power 4 coach for a top job; a
    mediocre ex-coach does not.
21. You can be fired midseason. Same rules as CPU coaches (weeks 4-11,
    2nd+ season). First you get a hot-seat warning from the AD (week
    message + newspaper). If things keep going badly, the AD can fire you.
    The game can't swap your coach out mid-season, so you coach out the
    year and are let go in the offseason carousel, where you pick a new
    job. A contract guarantee protects you.
22. AD coordinator recommendations. After the regular season the AD may
    recommend firing your OC, your DC, or both, when a unit badly
    underperforms its talent (for example, offense ranked #87 in scoring
    with the #31 offensive talent). You make the change in the carousel.
23. Players follow their old coach. When a head coach takes another head
    job, about 40-50% of his former players who enter the portal commit
    straight to his new school (up to 10 per school, scholarship room
    permitting). Newspaper story: "X players follow Coach Y to Z".
24. Transfer portal volume matches real life: depth players now enter
    the portal too (more for sophomores/juniors and deep reserves, less for
    freshmen; Loyal players never). Target: about 3,300 FBS entrants per
    year (about 24 per team), like the 3,300+ who entered in 2025-26.
    Real-life sign rate was 76%; in the game, unsigned portal players
    are removed at Advance Year, so check the portal page after your
    first offseason to see how close it lands.
25. Coach megadeals. A CPU head coach who wins the title (or plays for it,
    or has a top-4 season that beats expectations) at a prestige 5+ school
    gets a Cignetti-style extension: 8 years, up to about $13.3M a year,
    with a 3-year double-lock guarantee. If you do the same, a megadeal
    appears among your contract offers.
26. Firing notifications. Every firing (midseason and offseason), coach
    move, retirement and megadeal shows up in the League News newspaper,
    and the offseason carousel result message lists who was fired, who
    moved and who signed megadeals.
27. Real TV deals.
    - Conference TV money follows real 2024-25 per-school payouts,
      scaled to the game's money: Big Ten $16.6M, SEC $15M, ACC $9.8M,
      Big 12 $8.2M, American $2.3M, Pac-12 $2M, Mountain West $1.05M,
      Sun Belt $1.05M, MAC $0.85M, CUSA $0.65M (before the game's NIL
      bonus). Group of 5 values are estimates. These follow each
      conference's prestige slot in this universe (SEC 10, Big Ten 9,
      Big 12 8, ACC 7, Pac-12 6, Sun Belt 5, American 4, MAC 3, MWC 2,
      CUSA 1).
    - Every game gets a network and a real TV window from each
      conference's actual partners: Big Ten FOX (noon) / CBS (3:30) /
      NBC (7:30) plus FS1, BTN, Peacock; SEC ABC (3:30) and ESPN; Big 12
      FOX and ESPN/ABC; ACC ABC/ESPN plus a weekly The CW game; Pac-12
      CBS, CBSSN, USA, The CW; Mountain West CBS, FOX/FS1/FS2, The CW;
      American/Sun Belt/MAC on ESPN networks; CUSA CBSSN/ESPN+; Notre Dame
      home games on NBC; Army-Navy on CBS. West Coast teams don't kick off
      before 11 am local. Kickoff times now include :30 starts.
    - The network shows as a colored badge under the kickoff time on
      game cards and in the weather tooltip (text badge, not the
      networks' logos), and in newspaper game previews.
28. College GameDay and Big Noon Kickoff. Each week GameDay goes to the
    biggest game (rankings, rivalry, prestige; it won't return to the
    same campus within 3 weeks) and Big Noon Kickoff goes to FOX's noon
    game. Both show on the game card, the tooltip and in the newspaper.
29. No weather indoors: Syracuse (JMA Wireless Dome), UTSA (Alamodome)
    and UNLV (Allegiant Stadium) home games, plus neutral-site games at
    domes (Atlanta, Indianapolis, Detroit, New Orleans, Arlington,
    Houston, Glendale, Las Vegas, San Antonio, Minneapolis, St. Louis,
    SoFi).
30. Week 1 neutral-site kickoff games. Up to 6 of the best Power 4 vs
    Power 4 openers each year are moved to kickoff-classic sites nearest
    both schools: Atlanta (Aflac Kickoff), Arlington and Houston (Texas
    Kickoff), Las Vegas, Charlotte (Duke's Mayo Classic), Orlando (Camping
    World Kickoff), Nashville. Starts with the next schedule the game
    builds (2027 on your current save; 2026 on a new save). If OOC
    contracts are on, your own games are left alone.
31. Realistic injuries (Realistic setting). About 0.85 game-missing
    injuries per team per game (was 0.6); 25% miss 1 week, 21% 2 weeks,
    22% 3-4 weeks, 13% 5-7 weeks, 19% 8+ weeks (about 2 season-enders per
    team per year). More leg injuries, fewer head injuries; RBs and LBs
    get hurt most, kickers least.
32. Change settings after you start. League, School and Coaches settings
    (playoff format, transfers, NIL, contracts, etc.) can now be changed
    on the Game Settings page any time in the preseason or offseason.
    They're locked during the season.
33. 24-team playoff option (v3.14 replaced the selection and calendar; see
    NEW IN v3.14 above). Original v3.9 version: the 23 highest-ranked teams plus the
    best Group of 6 champion. Top 8 seeds get byes; seeds 9-16 host 17-24
    on campus the week conference title games used to be played; the top 8
    host round two; quarterfinals and semifinals at the New Year's Six
    bowls; title game mid-January. No conference championship games
    (conference champions are decided by the standings; Notre Dame isn't
    eligible for the ACC title). Turn it on in Game Settings in any
    offseason. If chosen for a new dynasty, the first season still uses
    the 12-team format. The bracket view shows both early rounds under
    "First Round".
34. Real history.
    - Coaches start with their real FBS career records through 2025
      (wins, losses, conference title game wins, national titles), which
      also feed the game's Coach Pedigree recruiting bonus and the
      carousel. On your current save this is added once when you load
      the game. (2025-only records are within about a game for coaches
      already counted into the 2026 season by the source.)
    - Program totals include real all-time records through 2025 and
      national titles (AP poll 1936-97, BCS/CFP 1998-2025), so the
      title screen says "Alabama's 13th national championship".
    - League History shows every real national champion and Heisman
      winner from 1935 to 2025.

INSTALL (quit FCCD with Command-Q first)
 In Steam: right-click the game > Manage > Browse local files.
 Control-click "Football Coach" > Show Package Contents > Contents > Resources.
 BACK UP the three originals first (copy them to a folder on your Desktop):
   Resources/app.asar
   Resources/app.asar.unpacked/dist/main/coreWorker.js
   Resources/app.asar.unpacked/dist/main/footballSimWorker.js
 Then drag in the three new files from this folder to the same places, choosing Replace.
 To confirm it installed, Get Info on Resources/app.asar should show 55,609,096 bytes
 (coreWorker.js 5,946,455 bytes, footballSimWorker.js 1,322,214 bytes).
 For the real 2026 schedule, start a new dynasty with
 2026_FBS_CFB27_RealNames_NoDivisions_Wk7_v310.json (included).

UNDO
 Put the three originals back, or Steam > Properties > Installed Files >
 Verify integrity of game files.

The source/ folder holds the build scripts and data (not needed to play).
v3.14 adds source/v314: build14.py patches the v3.13 app.asar, asartool.py
extracts and repacks it, and tests/ holds the checks described above.
