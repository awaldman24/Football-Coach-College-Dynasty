// ---------- v3.15: 2001 transfer rules (sit-out year, 2001 transfer volume, conference release) ----------
const __F01KIND="transfer-ineligible",__F01TARGET=650,__F01LAND=.4;
function __F01ON(st){try{st=st||P().leagueSettings;return"stock"!==(st&&st.fccdTransferRule)}catch(z){return!0}}
// yearly volume knob: nudges voluntary departures toward ~650 a year (2001 level)
function __F01TS(yr){try{const k="x01t_"+yr;let v=__FN.getState(k);if("number"==typeof v)return v;const pv=__FN.getState("x01t_"+(yr-1)),ps=__FN.getState("x01_"+(yr-1));v="number"==typeof pv?pv:1;ps&&ps.vol>0&&(v*=Math.min(1.4,Math.max(.7,__F01TARGET/ps.vol)));v=Math.min(3,Math.max(.3,v));__FN.setState(k,v);return v}catch(z){return 1}}
// who leaves (replaces the stock + earlier-mod leave decision when 2001 rules are on)
function __F01LEAVE(p,ix,st,yr,starter,m,f,r){try{if(!__F01ON())return r;if(r&&r.reason===c.TransferDecisionReason.BrokenPromise)return r;
 if((0,c.getPlayerPersonality)(p)===c.PlayerPersonality.Loyal)return{willTransfer:!1};
 const cl=(0,c.getPlayerClass)(p,yr),cm=cl===c.PlayerClass.Fr?1.2:cl===c.PlayerClass.So?1.3:cl===c.PlayerClass.Jr?1:.3;
 let q=(ix<st?.01:ix<2*st?.062:.12)*cm;const at=(0,c.getLastElementOfArr)(p.attributes),ovr=at?(0,c.getOverallRating)(p.position,at):60;
 starter&&ovr>=80&&(q*=.3);p.position===c.Position.K&&(q*=.3);
 const ch=!!(m&&f&&m.headCoachId&&f.headCoachId&&m.headCoachId!==f.headCoachId);ch&&(q*=1.6);q*=__F01TS(yr);
 if(__FR(`x01_${p.id}_${yr}`)>=q)return{willTransfer:!1};
 return ch?{willTransfer:!0,reason:c.TransferDecisionReason.PoorSchemeFit,details:"Coaching change"}:starter?{willTransfer:!0,reason:c.TransferDecisionReason.WantsToBeAStar,details:"Wants a bigger role"}:{willTransfer:!0,reason:c.TransferDecisionReason.WantsPlayingTime,details:"Wants playing time"}}catch(z){return r}}
// week "players transferring": some leavers drop to I-AA / juco (leave the league) so ~40% land at an FBS school
async function __F01MK(yr,r,p,d){try{if(!__F01ON())return[ue.markPlayersAsTransferring(d)];
 const dd=__FN.getState("x01_d",.35),drop=new Set,ov=new Map,w=o=>o<60?1.4:o<70?1:o<78?.6:.3;
 r.forEach(({player:e})=>{const at=(0,c.getLastElementOfArr)(e.attributes),o=at?(0,c.getOverallRating)(e.position,at):60;ov.set(e.id,[o,e]);__FR(`x01drop_${e.id}_${yr}`)<Math.min(.92,dd*w(o))&&drop.add(e.id)});
 p.forEach(id=>{__FR(`x01drop_${id}_${yr}`)<Math.min(.92,1.4*dd)&&drop.add(id)});
 const keep=d.filter(id=>!drop.has(id)),ts=__F01TS(yr);__FN.setState("x01_"+yr,{vol:r.length,cuts:p.length,drop:drop.size,ts,d:dd});
 try{const wk=P().mostRecentWeek.week+1,ui=P().user.teamId,TM=await J.getAllTeamsMap(),ids=[...ov.keys()],tys=ids.length?await x().playerTeamYear.findMany({where:{year:yr,playerId:{in:ids}},select:{playerId:!0,teamId:!0}}):[],T=new Map(tys.map(q=>[q.playerId,q.teamId])),nm=q=>TM.get(T.get(q))?.name??"?",L=[...ov.entries()].sort((a,b)=>b[1][0]-a[1][0]),pn=([id,[o,e]])=>`${e.position} ${e.firstName} ${e.lastName} (${nm(id)}${drop.has(id)?", to I-AA/juco":""})`;
  __FN.add(yr,wk,{label:"TRANSFER REPORT",score:705,teams:[],headline:`${r.length} players transfer out; ${drop.size} drop to I-AA or juco`,title:`Transfer report: ${r.length} players leave their schools`,subtitle:`${r.length} players are leaving their programs (plus ${p.length} not brought back for scholarship reasons). ${drop.size} are dropping down to I-AA or junior college; the rest are looking for an FBS home, where they will sit out a year. Biggest names: ${L.slice(0,5).map(pn).join("; ")||"none"}.`});
  const U=L.filter(([id])=>T.get(id)===ui);U.length&&__FN.add(yr,wk,{label:"TRANSFER REPORT",score:950,teams:[ui],headline:`${U.length} ${TM.get(ui)?.name??""} player${U.length>1?"s":""} transferring`,title:`${U.length} ${1===U.length?"player is":"players are"} leaving ${TM.get(ui)?.name??"your program"}`,subtitle:U.slice(0,10).map(pn).join("; ")+(U.length>10?" and others":"")+"."})}catch(z){console.log(">>> FCCD 2001 transfer news",z)}
 return[ue.markPlayersAsTransferring(keep),ue.markPlayersAsInactive([...drop])]}catch(z){console.log(">>> FCCD 2001 transfers",z);return[ue.markPlayersAsTransferring(d)]}}
// school permission to contact: 85% of transfers are refused permission to talk to conference rivals
async function __F01REL(e,t,s,l,u){if(!__F01ON())return;const CF=await ln(e),rel={},cid=id=>CF[id]?.id;
 s.forEach(p=>{const ty=(p.teamYears||[]).find(q=>q.year===e);if(!ty)return;const ca=cid(ty.teamId);ca&&__FR(`release_${p.id}_${e}`)<.85&&(rel[p.id]=ca)});
 const bad=(pid,tm)=>!!rel[pid]&&rel[pid]===cid(tm),keep=u.filter(q=>!bad(q.recruitId,q.teamId));u.length=0;u.push(...keep);
 l.forEach(q=>{q.committedTeamId&&bad(q.playerId,q.committedTeamId)&&(q.committedTeamId=null,q.committedWeek=null,q.committedNilOffer=0)});__FN.setState("x01rel_"+e,rel)}
async function __F01CM(e,cms){try{if(!__F01ON()||!cms.length)return cms;const rel=__FN.getState("x01rel_"+e,{});if(!Object.keys(rel).length)return cms;const CF=await ln(e);return cms.filter(q=>!(rel[q.recruitId]&&rel[q.recruitId]===CF[q.teamId]?.id))}catch(z){return cms}}
// advance year: every player on a new FBS team sits out the season (listed as "Sitting out (transfer)", like a season-long suspension)
async function __F01MARK(Y){try{if(!__F01ON())return;const k="x01m_"+Y;if(__FN.getState(k))return;
 const rows=await x().playerTeamYear.findMany({where:{year:{in:[Y-1,Y]}},select:{playerId:!0,teamId:!0,year:!0}}),prev=new Map,cur=new Map;rows.forEach(q=>(q.year===Y?cur:prev).set(q.playerId,q.teamId));
 const TM=await J.getAllTeamsMap(),mv=[];cur.forEach((tm,pid)=>{const a=prev.get(pid),tt=TM.get(tm);a&&a!==tm&&tt&&!tt.isFcs&&mv.push([pid,a,tm])});
 const ps=__FN.getState("x01_"+(Y-1));if(ps&&ps.vol+ps.cuts>0){const land=mv.length/(ps.vol+ps.cuts);ps.arr=mv.length;ps.land=land;__FN.setState("x01_"+(Y-1),ps);__FN.setState("x01_d",Math.min(.85,Math.max(0,(ps.d??.35)+.8*(land-__F01LAND))))}
 if(!mv.length){__FN.setState(k,{n:0});return}
 const PL=new Map((await x().player.findMany({where:{id:{in:mv.map(q=>q[0])},status:c.PlayerStatus.Active},include:{attributes:!0}})).map(q=>[q.id,q])),L=__FN.getState("susp_"+Y,[]),ops=[],sit=[],wv=[];
 mv.forEach(([pid,a,tm])=>{const pl=PL.get(pid);if(!pl)return;if(__FR(`x01w_${pid}_${Y}`)<.02){wv.push([pl,a,tm]);return}sit.push([pl,a,tm]);L.push({pid,team:tm,until:20,kind:__F01KIND});ops.push(x().playerInjury.upsert({where:{playerId:pid},create:{playerId:pid,teamId:tm,type:__F01KIND,severity:"severe",weeksLeft:20,weekSuffered:c.NEW_YEAR_PREV_WEEK},update:{teamId:tm,type:__F01KIND,severity:"severe",weeksLeft:20,weekSuffered:c.NEW_YEAR_PREV_WEEK}}))});
 for(let i=0;i<ops.length;i+=200)await x().$transaction(ops.slice(i,i+200));__FN.setState("susp_"+Y,L);__FN.setState(k,{n:sit.length,w:wv.length});
 try{const wk=c.NEW_YEAR_PREV_WEEK,ui=P().user.teamId,nm=q=>TM.get(q)?.name??"?",ov=pl=>{const at=(0,c.getLastElementOfArr)(pl.attributes);return at?(0,c.getOverallRating)(pl.position,at):0},S=sit.slice().sort((p,q)=>ov(q[0])-ov(p[0])),pn=([pl,a,tm])=>`${pl.position} ${pl.firstName} ${pl.lastName} (${nm(a)} to ${nm(tm)})`;
  __FN.add(Y,wk,{label:"TRANSFERS",score:760,teams:[],headline:`${sit.length} transfers must sit out ${Y}`,title:`Year in residence: ${sit.length} transfers ineligible this season`,subtitle:`Under NCAA transfer rules, ${sit.length} players who changed schools will sit out the ${Y} season${wv.length?` (${wv.length} received hardship waivers)`:""}. They practice with their new teams and play next year. Biggest names: ${S.slice(0,6).map(pn).join("; ")||"none"}.`});
  const U=sit.filter(q=>q[2]===ui),UW=wv.filter(q=>q[2]===ui);(U.length||UW.length)&&__FN.add(Y,wk,{label:"TRANSFERS",score:950,teams:[ui],headline:`${U.length} ${nm(ui)} transfer${1===U.length?"":"s"} sitting out`,title:`${nm(ui)} transfers: ${U.length} sitting out ${Y}`,subtitle:(U.length?`Sitting out: ${U.map(pn).join("; ")}.`:"")+(UW.length?` Eligible on a hardship waiver: ${UW.map(pn).join("; ")}.`:"")})}catch(z){console.log(">>> FCCD 2001 sit-out news",z)}
}catch(z){console.log(">>> FCCD 2001 mark error",z)}}
