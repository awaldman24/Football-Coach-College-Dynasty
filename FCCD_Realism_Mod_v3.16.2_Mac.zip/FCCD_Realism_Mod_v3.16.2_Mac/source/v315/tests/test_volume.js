// Runs the REAL patched Tt (transfer decisions) for all 138 teams on the universe rosters, 2001 rules vs stock-off.
const H=require('./harness'),{c0}=H,fs=require('fs'),path=require('path');
const U=JSON.parse(fs.readFileSync(path.join(__dirname,'../in/FCCD_Realism_Mod_v3.14_Mac/2026_FBS_CFB27_RealNames_NoDivisions_Wk7_v310.json')));
const teams={};let gid=0;U.players.forEach((p,i)=>{(teams[p.team]=teams[p.team]||[]).push({id:'p'+i,position:p.position,hsGradYear:p.hsGradYear,redshirtYear:(p.redshirtYear===null||p.redshirtYear===undefined||p.redshirtYear==='')?null:(typeof p.redshirtYear==='number'?p.redshirtYear:2025),recruitDetails:{},attributes:[{year:2026,...p.attributes}],passingYearStats:[],rushingReceivingYearStats:[],returningYearStats:[],offensiveLineYearStats:[],kickingPuntingYearStats:[],defenseYearStats:[],playerNilDeals:[]})});
// fill to 85 like the game's generator (deep reserves)
const POS=['QB','RB','WR','TE','OL','OL','DL','DL','LB','CB','S'];
Object.values(teams).forEach(L=>{while(L.length<85){const g=gid++;L.push({id:'g'+g,position:POS[g%POS.length],hsGradYear:2022+(g%4),redshirtYear:null,recruitDetails:{},attributes:[{year:2026,baselineOverall:45+(g*7)%15,potential:50}],passingYearStats:[],rushingReceivingYearStats:[],returningYearStats:[],offensiveLineYearStats:[],kickingPuntingYearStats:[],defenseYearStats:[],playerNilDeals:[]})}});
const names=Object.keys(teams);console.log('teams',names.length,'players',Object.values(teams).reduce((s,l)=>s+l.length,0));
async function run(rule,yr,tsOverride){const env=H.makeEnv({_e:()=>({playerPromises:{}}),dt:(s,t)=>({teamId:s,year:t,players:{}}),
  pt:async()=>({currentAttributes:{prestigePoints:20000},currentStats:{self:{wins:6,losses:6}}}),gt:()=>({offense:{},defense:{}}),
  __FSTAY:(p,y,f,r)=>r,__FUNHAPPY:(p,s,S,y,u,r)=>r,__FDEPTH:(p,ix,st,y,r)=>r});
  env.J.getActivePlayersForTeamYearWithAttributesAndStats=async e=>teams[e].map(p=>({playerId:p.id,player:p}));
  env.se.getAdaptedCoachesForTeamYear=async(e,t)=>({headCoachId:(t===yr+1&&(e.length%5===0))?'new_'+e:'hc_'+e,offensiveCoordinator:{offenseGamePlanTemplate:{}},defensiveCoordinator:{defenseGamePlanTemplate:{}}});
  env.yt.getAdaptedTeamCustomGamePlanYear=async()=>null;env.pe.getTotalCommitments=async()=>20;
  env.save.leagueSettings.fccdTransferRule=rule;
  const F=H.load(env,H.fnText('Tt'));if(tsOverride)env.st['x01t_'+yr]=tsOverride;
  let n=0,st=0,big=0,rs={},byCls={};const all=[];
  for(const t of names){const res=await F.Tt(t,yr,env.save);res.transfers.forEach(q=>{n++;const p=q.player;const sorted=env.c.getSortedPlayersByPosition(teams[t])[p.position];const ix=sorted.indexOf(p);const S=c0.APPROX_STARTERS_BY_POSITION[p.position];ix<S&&st++;ix<S&&p.attributes[0].baselineOverall>=80&&big++;rs[q.transferDecision.details]=(rs[q.transferDecision.details]||0)+1;const cl=c0.getPlayerClass(p,yr);byCls[cl]=(byCls[cl]||0)+1;all.push(q)})}
  return{n,st,big,rs,byCls,ts:env.st['x01t_'+yr],all,env,F}}
(async()=>{const r1=await run('2001',2026);console.log('2001 rules: leavers',r1.n,'per team',(r1.n/138).toFixed(1),'starters',r1.st,`(${(100*r1.st/r1.n).toFixed(0)}%)`,'80+ starters',r1.big,'tscale',r1.ts);console.log(' reasons',r1.rs,' class',r1.byCls);
 const r0=await run('stock',2026);console.log(r0.rs,'stock (mod chain stubbed, getPlayerTransferDecision stubbed=never):',r0.n,'-> stock path unchanged when off');
 // determinism: same call twice
 const r2=await run('2001',2026);console.log('deterministic:',r1.n===r2.n&&r1.all.every((q,i)=>q.player.id===r2.all[i].player.id));
 fs.writeFileSync(path.join(__dirname,'vol_out.json'),JSON.stringify({n:r1.n,st:r1.st,big:r1.big}));
})().catch(e=>{console.error(e);process.exit(1)});
