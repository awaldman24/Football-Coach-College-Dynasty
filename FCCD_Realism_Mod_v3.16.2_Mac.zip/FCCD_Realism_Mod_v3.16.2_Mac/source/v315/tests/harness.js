// Loads the REAL patched main.js code (helpers + Tt) and runs it against mocks + the real universe rosters.
const fs=require('fs'),path=require('path');
const B=path.join(__dirname,'../b/dist/main/main.js');
const L=require('../tools/loader')(B);const c0=L(11709);
const src=L.src;
function fnText(name){const acorn=require('acorn'),walk=require('acorn-walk');if(!fnText.ast)fnText.ast=acorn.parse(src,{ecmaVersion:'latest'});let out=null;walk.full(fnText.ast,n=>{if(n.type==='FunctionDeclaration'&&n.id&&n.id.name===name&&!out)out=src.slice(n.start,n.end)});if(!out)throw new Error('no fn '+name);return out}
const a0=src.indexOf('// ---------- v3.15: 2001 transfer rules'),a1=src.indexOf('let qa=null;const za=[19,15,12];async function Wa(');
const helpers=src.slice(a0,a1);
// c with test overrides (universe players only carry an overall, not the 22 sub-ratings)
const c=Object.create(c0);
const ov=(k,f)=>Object.defineProperty(c,k,{value:f,writable:!0,enumerable:!0});
ov('getOverallRating',(pos,at)=>at.baselineOverall);
ov('getSortedPlayersByPosition',(pl)=>{const o={};Object.values(c0.Position).forEach(p=>o[p]=[]);pl.forEach(p=>o[p.position].push(p));Object.values(o).forEach(a=>a.sort((x,y)=>y.attributes[0].baselineOverall-x.attributes[0].baselineOverall));return o});
ov('getPlayerTransferDecision',()=>({willTransfer:!1}));
function makeEnv(over){const st={},news=[];const env={c,k:{},
  P:()=>env.save,save:{saveId:'t',leagueSettings:{...c0.DEFAULT_LEAGUE_SETTINGS},user:{type:'coach',role:'HC',teamId:'Wisconsin'},mostRecentWeek:{year:2026,week:23}},
  __FN:{getState:(k,d)=>k in st?JSON.parse(JSON.stringify(st[k])):d,setState:(k,v)=>{st[k]=JSON.parse(JSON.stringify(v))},add:(y,w,s)=>news.push({y,w,...s})},
  __FR:sd=>c0.randomNumberGivenSeed(0,1,sd),st,news,
  ue:{markPlayersAsTransferring:ids=>({op:'transfer',ids:[...ids]}),markPlayersAsInactive:ids=>({op:'inactive',ids:[...ids]})},
  J:{},x:()=>env.db,ln:async()=>env.conf,pe:{},se:{},yt:{},db:{},conf:{},...over};return env}
function load(env,extra=''){const names=['c','k','P','__FN','__FR','ue','J','x','ln','pe','se','yt','_e','dt','pt','gt','__FSTAY','__FUNHAPPY','__FDEPTH'];
  const body=helpers+'\n'+extra+'\nreturn{__F01ON,__F01TS,__F01LEAVE,__F01MK,__F01REL,__F01CM,__F01MARK'+(extra?',Tt':'')+'}';
  return new Function(...names,body)(...names.map(n=>env[n]))}
module.exports={c0,c,src,fnText,makeEnv,load};
