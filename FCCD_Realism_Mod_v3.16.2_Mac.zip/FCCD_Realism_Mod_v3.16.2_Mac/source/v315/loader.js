// mini webpack require for running real modules from a bundle in node
// usage: const L=require('./loader')(bundlePath); const c=L(11709);
const fs=require('fs'),acorn=require('acorn');
module.exports=function(file){
  const src=fs.readFileSync(file,'utf8');const ast=acorn.parse(src,{ecmaVersion:'latest'});
  // find the largest ObjectExpression whose properties are numeric-keyed functions
  let best=null;
  (function v(n){if(!n||typeof n!=='object')return;if(Array.isArray(n))return n.forEach(v);
    if(n.type==='ObjectExpression'&&n.properties.length>200&&n.properties.every(p=>p.key&&(p.key.type==='Literal'&&typeof p.key.value==='number'))){if(!best||n.properties.length>best.properties.length)best=n}
    for(const k in n){if(k!=='type'&&n[k]&&typeof n[k]==='object')v(n[k])}})(ast);
  const fac={};best.properties.forEach(p=>{fac[p.key.value]=src.slice(p.value.start,p.value.end)});
  const cache={};
  function req(id){if(cache[id])return cache[id].exports;const m={exports:{},id,loaded:!1};cache[id]=m;
    const f=eval('('+fac[id]+')');f.call(m.exports,m,m.exports,req);return m.exports}
  req.n=m=>{const g=m&&m.__esModule?()=>m.default:()=>m;g.a=g;return g};
  req.d=(e,d)=>{for(const k in d)Object.defineProperty(e,k,{enumerable:!0,get:d[k]})};
  req.o=(o,p)=>Object.prototype.hasOwnProperty.call(o,p);
  req.r=e=>Object.defineProperty(e,'__esModule',{value:!0});
  req.nmd=m=>m;req.hmd=m=>m;req.amdD=function(){throw new Error('amd')};req.g=globalThis;
  globalThis.require=globalThis.require||require;
  req.fac=fac;req.src=src;return req};
