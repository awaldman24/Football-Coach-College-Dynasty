#!/usr/bin/env python3
"""FCCD Realism Mod v3.15 build: 2001 transfer rules. Patches main.js and renderer.js extracted from the v3.14 app.asar.
usage: build15.py EXTRACT_DIR SRC_DIR   (writes patched files in place under EXTRACT_DIR)"""
import sys, os
EX, SRC = sys.argv[1], sys.argv[2]
MAIN = os.path.join(EX, 'dist/main/main.js')
REND = os.path.join(EX, 'dist/renderer/renderer.js')
rd = lambda p: open(p, encoding='utf-8').read()
m = rd(MAIN); r = rd(REND)

def rep(s, old, new, label, count=1):
    n = s.count(old)
    if n != count:
        sys.exit(f'PATCH FAIL {label}: found {n}, expected {count}')
    print('ok', label)
    return s.replace(old, new)

# ---------- main.js ----------
A = 'let qa=null;const za=[19,15,12];async function Wa('
m = rep(m, A, rd(os.path.join(SRC, 'x01.js')).strip() + '\n\n' + A, 'M1 helpers')
# M2 leave decision (2001 model wraps the whole existing chain)
m = rep(m, 'r=__FSTAY(e,t,f,__FUNHAPPY(', 'r=__F01LEAVE(e,s,a,t,n,m,f,__FSTAY(e,t,f,__FUNHAPPY(', 'M2a leave wrap open')
m = rep(m, 'nextYearScheme:L})))));return!o&&r.willTransfer', 'nextYearScheme:L}))))));return!o&&r.willTransfer', 'M2b leave wrap close')
# M3 week "players transferring": drop-downs + counts + transfer report
m = rep(m, '[s?ue.markPlayersAsTransferring(d):ue.markPlayersAsInactive(d),',
        '[...(s?await __F01MK(a,r,p,d):[ue.markPlayersAsInactive(d)]),', 'M3 portal entry')
# M4 advance year: mark sit-outs for the new season
m = rep(m, 'i.addEvent("Transact advance year"),We(),zt(),', 'i.addEvent("Transact advance year"),We(),zt(),await __F01MARK(a+1),', 'M4 advance year')
# M5 permission to contact (conference rivals)
F = 'try{await __FFOLLOW(e,t,n,s,l,u)}catch(z0){console.log(">>> ERROR fccd follow coach",z0)}'
m = rep(m, F, F + 'try{await __F01REL(e,t,s,l,u)}catch(z0){console.log(">>> ERROR fccd 2001 release",z0)}', 'M5 release block')
m = rep(m, '...T.commitments.map((e=>pe.updatePlayerCommitment(e,t)))', '...(await __F01CM(e,T.commitments)).map((e=>pe.updatePlayerCommitment(e,t)))', 'M6 commitments')
# M7 following a coach was rare in 2001 (and they still sat)
F = 'if((0,c.randomNumberGivenSeed)(0,1,`follow_${p.id}_${e}`)>=pf)continue;'
m = rep(m, F, '__F01ON()&&(pf*=.25);' + F, 'M7 follow coach')
# M8 display: "Sitting out (transfer)", ratings unchanged on screens
m = rep(m, '"academic-ineligible"===t.type)return e;', '"academic-ineligible"===t.type||"transfer-ineligible"===t.type)return e;', 'M8a attrs')
m = rep(m, 'if("academic-ineligible"===t)return"Academically ineligible";', 'if("academic-ineligible"===t)return"Academically ineligible";if("transfer-ineligible"===t)return"Sitting out (transfer)";', 'M8b name')

# ---------- renderer.js ----------
B = 'onChange:i=>e?.({...t,fccdBcs:i}),disabled:!e},void 0),'
r = rep(r, B, B + '(0,n.jsx)(O,{label:"2001 transfer rules",value:t.fccdTransferRule??"2001",onValue:"2001",offValue:"stock",'
        'onTooltip:"Transfers sit out their first season at the new school (hardship waivers are rare), about 650 players a year transfer (mostly backups), many drop to I-AA or juco, and schools usually refuse permission to talk to conference rivals.",'
        'offTooltip:"The game\'s own transfer portal: transfers play right away.",onChange:i=>e?.({...t,fccdTransferRule:i}),disabled:!e},void 0),', 'R1 toggle')
r = rep(r, '"academic-ineligible"===e.type)return t;', '"academic-ineligible"===e.type||"transfer-ineligible"===e.type)return t;', 'R2a attrs')
r = rep(r, 'if("academic-ineligible"===e)return"Academically ineligible";', 'if("academic-ineligible"===e)return"Academically ineligible";if("transfer-ineligible"===e)return"Sitting out (transfer)";', 'R2b name')

open(MAIN, 'w', encoding='utf-8').write(m)
open(REND, 'w', encoding='utf-8').write(r)
print('done')
