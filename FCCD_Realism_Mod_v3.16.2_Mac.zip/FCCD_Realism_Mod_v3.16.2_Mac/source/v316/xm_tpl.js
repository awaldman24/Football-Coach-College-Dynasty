// ---------- v3.16: money drives everything (real 2026 football money, donor momentum, prestige follows money) ----------
const __FM_BASE=__BASE_JSON__;
const __FM_K=500,__FM_TIERS=[[47,10],[40,9],[31,8],[24,7],[18,6],[12,5],[7,4],[5.5,3],[4,2],[0,1]],__FM_PDEF=[0,3.5,4.8,6.2,9.5,15,21,27.5,35.5,43.5,50];
function __FMON(st){try{st=st||P().leagueSettings;return"off"!==(st&&st.fccdMoney)&&(0,c.isNilEnabled)(st.nil)}catch(z){return!1}}
function __FMREAL(name,pl){const m=__FM_BASE[name];return"number"==typeof m?m:__FM_PDEF[Math.max(1,Math.min(10,pl||3))]}
function __FMST(){let s=__FN.getState("fm",null);(!s||"object"!=typeof s)&&(s={mm:{},mmy:{},yr:{}});s.mm||(s.mm={});s.mmy||(s.mmy={});s.yr||(s.yr={});return s}
function __FMLVL(annual){const r=annual/__FM_K;for(const[t,l]of __FM_TIERS)if(r>=t)return l;return 1}
function __FMW(b){return b>0?Math.min(1.6,Math.max(.5,Math.sqrt(b/9e3))):1}
// offseason school update (rn): money momentum from the season, next year's NIL budget, prestige drift toward the level the money buys
const __FMC=new Map;
function __FMCALC(e,a,i,s,n,l,b,I0){try{if(!__FMON(e)||!a||a.isFcs||!s)return I0;
 const st=__FMST(),id=a.id,pl=(0,c.getPrestigeLevelFromPoints)(s.currentAttributes.prestigePoints);let m=st.mm[id]??0;
 if(st.mmy[id]!==i){const perf=Math.max(-1,Math.min(1.5,(b||0)/3e3));m=Math.round(1e3*(.65*m+.35*perf))/1e3;st.mm[id]=m;st.mmy[id]=i}
 const base=Math.round(__FM_K*__FMREAL(a.name,pl)),mult=1+.4*m,annual=Math.round(base*mult),
  rem=Math.max(0,(0,c.getTotalNilMoneyRemaining)(s.currentAttributes.nilPoints,n,!1)),
  bud=Math.round(Math.min(6e4,Math.max(300,.5*rem+annual+.2*Math.max(0,l&&l.nilSpending||0)))),
  lv=__FMLVL(annual),tgt=lv>=10?5e4:((0,c.getPrestigePointsFromLevel)(lv)+(0,c.getPrestigePointsFromLevel)(lv+1))/2,
  I=Math.round((0,c.constrainNumber)(I0+.12*(tgt-I0),c.MIN_PRESTIGE_POINTS,c.MAX_PRESTIGE_POINTS));
 __FMC.set(id+"_"+i,bud);const Y=String(i+1);(st.yr[Y]=st.yr[Y]||{})[id]={n:a.name,b:bud,a:annual,m,lv,p0:I0,p1:I};
 const ks=Object.keys(st.yr).sort();ks.length>6&&ks.slice(0,ks.length-6).forEach(q=>{delete st.yr[q]});__FN.setState("fm",st);return I}catch(z){console.log(">>> FCCD money calc",z);return I0}}
function __FMNIL(e,a,i,orig){try{if(!__FMON(e)||!a)return orig;const v=__FMC.get(a.id+"_"+i);return"number"==typeof v?v:orig}catch(z){return orig}}
function __FMBUD(id,yr){try{const st=__FN.getState("fm",null),r=st&&st.yr&&(st.yr[String(yr)]||st.yr[String(yr+1)]);return r&&r[id]?r[id].b:null}catch(z){return null}}
// players' decision to leave: rich collectives pay their own players to stay; poor schools get their good starters bought away
function __FMSTAY(ix,nst,yr,starter,S,p,r){try{if(!__FMON()||!r||!S||!S.currentAttributes)return r;const tid=S.currentAttributes.teamId;if(r.reason===c.TransferDecisionReason.BrokenPromise)return r;if(tid===P().user.teamId)return r;
 if((0,c.getPlayerPersonality)(p)===c.PlayerPersonality.Loyal)return r;
 const b=__FMBUD(tid,yr)??(S&&S.currentAttributes?S.currentAttributes.nilPoints:0),w=__FMW(b);
 if(r.willTransfer){if(w>1&&__FR(`fmstay_${p.id}_${yr}`)<Math.min(.5,.6*(w-1)))return{willTransfer:!1};return r}
 if(w<1&&starter){const at=(0,c.getLastElementOfArr)(p.attributes),o=at?(0,c.getOverallRating)(p.position,at):0;
  if(o>=76&&__FR(`fmpoach_${p.id}_${yr}`)<Math.min(.3,(1-w)*(o>=82?.45:.25)))return{willTransfer:!0,reason:c.TransferDecisionReason.WantsToWin,details:"Bigger NIL offer elsewhere"}}
 return r}catch(z){return r}}
// one-time switch of the current season's NIL pools to money (existing saves and brand-new dynasties)
async function __FMINIT(){try{if(!__FMON())return;const yr=P().mostRecentWeek.year,k="fminit";if(__FN.getState(k,0))return;
 const TM=await J.getAllTeamsMap(),rows=await x().teamAttributes.findMany({where:{year:yr},select:{teamId:!0,prestigePoints:!0,nilPoints:!0}}),ops=[],st=__FMST(),Y=String(yr);st.yr[Y]=st.yr[Y]||{};
 rows.forEach(q=>{const t=TM.get(q.teamId);if(!t||t.isFcs)return;const pl=(0,c.getPrestigeLevelFromPoints)(q.prestigePoints),b=Math.round(__FM_K*__FMREAL(t.name,pl));
  st.yr[Y][q.teamId]={n:t.name,b,a:b,m:0,lv:__FMLVL(b),p0:q.prestigePoints,p1:q.prestigePoints};ops.push(x().teamAttributes.updateMany({where:{teamId:q.teamId,year:yr},data:{nilPoints:b}}))});
 for(let j=0;j<ops.length;j+=200)await x().$transaction(ops.slice(j,j+200));__FN.setState("fm",st);__FN.setState(k,{yr,n:ops.length});
 try{const ui=P().user.teamId,R=Object.entries(st.yr[Y]).sort((p,q)=>q[1].b-p[1].b),u=st.yr[Y][ui],ur=R.findIndex(q=>q[0]===ui)+1,D=(0,c.getDollarDisplay);
  __FN.add(yr,P().mostRecentWeek.week+1,{label:"MONEY",score:900,teams:[],headline:"Money now runs college football",title:"The NIL era: every program now spends its real budget",subtitle:`Every school's NIL budget now comes from its real 2026 football money, and computer-run schools now have to recruit within it. Richest: ${R.slice(0,5).map(q=>`${q[1].n} ${D(q[1].b)}`).join(", ")}.${u?` ${u.n}: ${D(u.b)} (#${ur} of ${R.length}).`:""}`})}catch(z){}
}catch(z){console.log(">>> FCCD money init",z)}}
// offseason money report (after school updates)
function __FMNEWS(yr){try{if(!__FMON())return;const st=__FN.getState("fm",null),Y=String(yr+1),R=st&&st.yr&&st.yr[Y];if(!R)return;const E=Object.entries(R),D=(0,c.getDollarDisplay),ui=P().user.teamId,wk=P().mostRecentWeek.week+1;
 const top=E.slice().sort((p,q)=>q[1].b-p[1].b),mv=E.slice().sort((p,q)=>q[1].m-p[1].m),lvl=q=>(0,c.getPrestigeLevelFromPoints)(q),up=E.filter(q=>lvl(q[1].p1)>lvl(q[1].p0)),dn=E.filter(q=>lvl(q[1].p1)<lvl(q[1].p0));
 __FN.add(yr,wk,{label:"MONEY REPORT",score:820,teams:[],headline:`${top[0][1].n} leads with a ${D(top[0][1].b)} NIL budget`,title:`Money report: ${yr+1} NIL budgets`,subtitle:`Biggest budgets: ${top.slice(0,6).map(q=>`${q[1].n} ${D(q[1].b)}`).join(", ")}. Donors are buzzing at ${mv.slice(0,3).map(q=>q[1].n).join(", ")}; giving is drying up at ${mv.slice(-3).reverse().map(q=>q[1].n).join(", ")}.${up.length?` Prestige rising with the money: ${up.slice(0,6).map(q=>q[1].n).join(", ")}.`:""}${dn.length?` Falling behind financially: ${dn.slice(0,6).map(q=>q[1].n).join(", ")}.`:""}`});
 const u=R[ui];if(u){const rk=top.findIndex(q=>q[0]===ui)+1;__FN.add(yr,wk,{label:"MONEY REPORT",score:950,teams:[ui],headline:`${u.n} NIL budget: ${D(u.b)} (#${rk})`,title:`${u.n} has ${D(u.b)} to spend in ${yr+1}`,subtitle:`That ranks #${rk} of ${top.length}. Donor mood ${u.m>=.25?"is hot after the season":u.m<=-.25?"has cooled after the season":"is steady"} (giving at ${Math.round(100*(1+.4*u.m))}% of the program's base).`})}}catch(z){console.log(">>> FCCD money news",z)}}
