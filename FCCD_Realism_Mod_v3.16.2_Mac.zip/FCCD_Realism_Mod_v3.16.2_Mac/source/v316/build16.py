#!/usr/bin/env python3
"""FCCD Realism Mod v3.16 build: money drives everything. Patches main.js + renderer.js (extracted from v3.15 app.asar) and coreWorker.js (v3.15).
usage: build16.py EXTRACT_DIR COREWORKER_JS SRC_DIR   (writes patched files in place)"""
import sys, os
EX, CW, SRC = sys.argv[1], sys.argv[2], sys.argv[3]
MAIN = os.path.join(EX, 'dist/main/main.js'); REND = os.path.join(EX, 'dist/renderer/renderer.js')
rd = lambda p: open(p, encoding='utf-8').read()
m = rd(MAIN); r = rd(REND); w = rd(CW)
def rep(s, old, new, label, count=1):
    n = s.count(old)
    if n != count: sys.exit(f'PATCH FAIL {label}: found {n}, expected {count}')
    print('ok', label); return s.replace(old, new)
# ---------- main.js ----------
A = 'let qa=null;const za=[19,15,12];async function Wa('
m = rep(m, A, rd(os.path.join(SRC, 'xm.js')).strip() + '\n\n' + A, 'M1 helpers')
m = rep(m, 'I=(0,c.constrainNumber)(o+b,c.MIN_PRESTIGE_POINTS,c.MAX_PRESTIGE_POINTS)',
        'I=__FMCALC(e,a,i,s,n,l,b,(0,c.constrainNumber)(o+b,c.MIN_PRESTIGE_POINTS,c.MAX_PRESTIGE_POINTS))', 'M2 prestige drift + budget')
m = rep(m, 'nilPoints:(0,c.constrainNumberNilCap)(C,e.nil,P)', 'nilPoints:__FMNIL(e,a,i,(0,c.constrainNumberNilCap)(C,e.nil,P))', 'M3 nil budget')
m = rep(m, 'r=__F01LEAVE(e,s,a,t,n,m,f,', 'r=__FMSTAY(s,a,t,n,S,e,__F01LEAVE(e,s,a,t,n,m,f,', 'M4a retention open')
m = rep(m, 'nextYearScheme:L}))))));return!o&&r.willTransfer', 'nextYearScheme:L})))))));return!o&&r.willTransfer', 'M4b retention close')
m = rep(m, 'As(t,"Updated schools.")', '(__FMNEWS(l),As(t,"Updated schools."))', 'M5 money report')
F = 'try{await __FBACKFILL()}catch(z0){console.log(">>> ERROR fccd career backfill",z0)}'
m = rep(m, F, F + 'try{await __FMINIT()}catch(z0){console.log(">>> ERROR fccd money init",z0)}', 'M6 money init')
m = rep(m, 'return"stock"!==(st&&st.fccdTransferRule)', 'return"2001"===(st&&st.fccdTransferRule)', 'M7 2001 rules default off')
# ---------- renderer.js ----------
r = rep(r, 'value:t.fccdTransferRule??"2001"', 'value:t.fccdTransferRule??"stock"', 'R1 2001 default off')
B = 'offTooltip:"The game\'s own transfer portal: transfers play right away.",onChange:i=>e?.({...t,fccdTransferRule:i}),disabled:!e},void 0),'
r = rep(r, B, B + '(0,n.jsx)(O,{label:"Money drives everything",value:t.fccdMoney??"on",onValue:"on",offValue:"off",'
        'onTooltip:"Every school\'s NIL budget comes from its real 2026 football money, grows when it wins and shrinks when it loses, and computer-run schools must recruit and buy transfers within it (rich schools bid more). Rich collectives keep their players; poor schools get starters bought away. Prestige drifts toward the level the money buys. Needs NIL turned on.",'
        'offTooltip:"The game\'s own NIL: budgets come from prestige and computer-run schools bid as if money were unlimited.",onChange:i=>e?.({...t,fccdMoney:i}),disabled:!e},void 0),', 'R2 money toggle')
# ---------- coreWorker.js ----------
w = rep(w, 'if(n.isUserTeam){', 'if(n.isUserTeam||"off"!==i.fccdMoney){', 'C1 CPU NIL budget enforced')
w = rep(w, 'S=Math.round(p*g*s)', 'S=Math.round(p*g*s*("off"!==e.fccdMoney&&o&&o.totalNilBudget>0?Math.min(1.6,Math.max(.5,Math.sqrt(o.totalNilBudget/9e3))):1))', 'C2 bids scale with money')
w = rep(w, 'return Math.round(75*c*d*(t/l))', 'return Math.round((a&&"off"===a.fccdMoney?75:100)*c*d*(t/l))', 'C3 NIL weight')
open(MAIN, 'w', encoding='utf-8').write(m); open(REND, 'w', encoding='utf-8').write(r); open(CW, 'w', encoding='utf-8').write(w)
print('done')
