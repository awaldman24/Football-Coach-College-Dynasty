const {H,c,store}=require('./test_rn.js');
// budgets for the stay test
store.fm={mm:{},mmy:{},yr:{"2026":{rich:{b:25750},mid:{b:9000},poor:{b:2700},wis:{b:14500}}}};
// real c, but players need full attribute sets; stub overall/personality through a Proxy-built copy of the helper
const src=require('fs').readFileSync('/tmp/claude-0/-home-claude/ecf3cc5b-4edc-5f64-b5a6-7caf12416a80/scratchpad/v316/xm.js','utf8');
const c2=new Proxy(c,{get:(o,k)=>k==='getOverallRating'?((pos,a)=>a.ovr):k==='getPlayerPersonality'?(p=>p.pers):o[k]});
const __FN={getState:(k,d)=>store[k]===undefined?d:store[k],setState(){},add(){}};
const P=()=>({leagueSettings:{nil:'on-prestige-cap'},user:{teamId:'wis'},mostRecentWeek:{year:2026,week:23}});
const __FR=s=>{let h=2166136261;for(const ch of s){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0}return (h%100000)/100000};
const F=new Function('c','__FN','P','__FR',src+';return __FMSTAY')(c2,__FN,P,__FR);
for(const tid of ['rich','mid','poor','wis']){
 let kept=0,leavers=0,poached=0,N=20000;
 for(let i=0;i<N;i++){const p={id:'p'+i,position:'QB',attributes:[{ovr:70+(i%20)}],pers:'x'};
  const S={currentAttributes:{teamId:tid,nilPoints:0}};
  const out1=F(0,1,2026,false,S,p,{willTransfer:true,reason:'wants-playing-time'});leavers++;if(!out1.willTransfer)kept++;
  const out2=F(0,1,2026,true,S,p,{willTransfer:false});if(out2.willTransfer)poached++;}
 console.log(tid.padEnd(5),'w',c.getDollarDisplay(store.fm.yr["2026"][tid].b),'leavers kept by collective',(100*kept/leavers).toFixed(1)+'%','| starters (70-89 OVR) bought away',(100*poached/N).toFixed(1)+'%');
}
