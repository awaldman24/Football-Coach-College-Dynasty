// runs the REAL patched rn()/pn() from main.js plus the injected money helpers, with the real shared lib (module 11709)
const fs=require('fs');const T='/tmp/claude-0/-home-claude/ecf3cc5b-4edc-5f64-b5a6-7caf12416a80/scratchpad/';
module.paths.push(T+'tools/node_modules');
const L=require(T+'tools/loader')(T+'build/ex/dist/main/main.js');const c=L(11709);
const src=L.src;const cut=(a,b)=>{const i=src.indexOf(a);const j=src.indexOf(b,i);return src.slice(i,j)};
const helpers=cut('// ---------- v3.16: money drives everything','\n\nlet qa=null;');
const rnSrc=cut('function rn(e,t,a,i,s,n,l,u,r,p){','async function on(e){');
const store={};const __FN={getState:(k,d)=>store[k]===undefined?d:store[k],setState:(k,v)=>{store[k]=JSON.parse(JSON.stringify(v))},add:(y,w,s)=>{(store.news=store.news||[]).push(s)}};
const settings={nil:c.NilSetting.OnPrestigeCap,schoolAttributesCost:Object.values(c.SchoolAttributesCostSetting||{})[0],fanbasePassion:c.FanbasePassionSetting.Simple};
const P=()=>({leagueSettings:settings,user:{teamId:'wis'},mostRecentWeek:{year:2026,week:29}});
const __FR=s=>{let h=0;for(const ch of s)h=(h*31+ch.charCodeAt(0))>>>0;return (h%10000)/10000};
const _g=c.getPrestigeGainOrLoss;const c2=new Proxy(c,{get:(o,k)=>k==="getPrestigeGainOrLoss"?(()=>o.__g||0):o[k]});const f=new Function('c','__FN','P','__FR','x','J',helpers+'\n'+rnSrc+'\nreturn {rn,__FMCALC,__FMSTAY,__FMNEWS,__FMW};');
const H=f(c2,__FN,P,__FR,null,null);
module.exports={H,c,store,settings};
if(require.main===module){
 const teams=[['osu','Ohio State',10,49000],['uga','Georgia',10,49000],['wis','Wisconsin',7,24000],['lou','Louisville',6,18000],['kent','Kent State',1,500],['usf','South Florida',4,8000],['zzz','Made Up U',3,4500]];
 const nd={committedNilOffersTotal:0,outstandingNilOffersTotal:0,convinceCurrentPlayersNilMoneySpent:0,transferringPlayersNilMoneyReturned:0};
 const perfSeq={osu:[2000,2000,-500,3000,1000],uga:[0,-1000,0,500,-200],wis:[4000,4000,4000,4000,4000],lou:[-3000,-3000,-3000,-2000,-1000],kent:[0,0,0,0,0],usf:[1500,1500,1500,1500,1500],zzz:[0,0,0,0,0]};
 const st={};teams.forEach(([id,n,pl,pp])=>st[id]={prestigePoints:pp,nilPoints:c.getNilCapFromPrestige(pl)});
 for(let y=2026;y<2031;y++){console.log('--- offseason after',y);
  teams.forEach(([id,name])=>{const a={id,name,isFcs:false};const s={currentAttributes:{teamId:id,...st[id],facilityPoints:5000,stadiumPoints:5000,collegeLifePoints:5000,academicPoints:5000,marketingPoints:5000,attendance:40000,fanbasePoints:5}};
   const spend={facilitySpending:0,stadiumSpending:0,collegeLifeSpending:0,academicSpending:0,marketingSpending:0,nilSpending:3000};
   // simulate the team spending 70% of its pool during the year
   const used=Math.round(.7*st[id].nilPoints);const n={...nd,committedNilOffersTotal:used};
   // fake prestige gain via stubbing getPrestigeGainOrLoss
   c.__g=perfSeq[id][y-2026];
   const out=H.rn(settings,138,a,y,s,n,spend,0,null,false);
   st[id]={prestigePoints:out.attributes.prestigePoints,nilPoints:out.attributes.nilPoints};
   const r=store.fm.yr[String(y+1)][id];
   console.log(`${name.padEnd(14)} gain ${String(c.__g).padStart(5)} mom ${r.m.toFixed(2).padStart(5)} annual ${c.getDollarDisplay(r.a).padStart(8)} budget ${c.getDollarDisplay(out.attributes.nilPoints).padStart(8)} prestige ${c.getPrestigeLevelFromPoints(r.p0)}->${c.getPrestigeLevelFromPoints(out.attributes.prestigePoints)} (${out.attributes.prestigePoints})`)});
  H.__FMNEWS(y);}
 console.log(store.news.map(s=>s.title+' | '+s.subtitle).join('\n'));
}
