const T='/tmp/claude-0/-home-claude/ecf3cc5b-4edc-5f64-b5a6-7caf12416a80/scratchpad/';
module.paths.push(T+'tools/node_modules');
// stub getPrestigeGainOrLoss on the shared lib before the test module binds it
const L=require(T+'tools/loader');
