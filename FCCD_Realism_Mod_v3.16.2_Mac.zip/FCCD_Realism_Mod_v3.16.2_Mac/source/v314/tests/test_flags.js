const fs=require('fs'),vm=require('vm'),assert=require('assert');const W=process.argv[2];
const r=fs.readFileSync(W+'/ex14/dist/renderer/renderer.js','utf8');const head=r.slice(0,r.indexOf(';(function(){if(globalThis.__FNB)'));
const ctx={};ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(head,ctx);
const E={ConfChampWeek:'cc',PreBowlWeek:'pb'};
// constants module getter, emulated exactly as patched
const e={WEEK_CCG:14,WEEK_PRE_BOWL:15};Object.defineProperty(e,"AWARDS_WEEK",{get:()=>ctx.__FAW24?e.WEEK_CCG:e.WEEK_PRE_BOWL,enumerable:true,configurable:true});
const S=(fmt,ccg,y,sy)=>({leagueSettings:{playoffFormat:fmt,ccgUseHighestRanked:ccg},startingYear:sy,mostRecentWeek:{year:y}});
ctx.__FFLAGS(S('24-team-23-plus-1','none',2026,2026));assert.equal(e.AWARDS_WEEK,15);assert.equal(ctx.__FWKL('cc',E,'Conf Champ Week'),'Conf Champ Week');
ctx.__FFLAGS(S('24-team-23-plus-1','none',2027,2026));assert.equal(e.AWARDS_WEEK,14);assert.equal(ctx.__FWKL('cc',E,'x'),'Army-Navy & Awards');assert.equal(ctx.__FWKL('pb',E,'x'),'CFP First Round');
ctx.__FFLAGS(S('four-conf-champs-8-at-large-no-cc-bye','fccd-no-ccg',2027,2026));assert.equal(e.AWARDS_WEEK,15);assert.equal(ctx.__FWKL('cc',E,'x'),'Open Week (no CCGs)');assert.equal(ctx.__FWKL('pb',E,'Awards Week'),'Awards Week');
ctx.__FFLAGS(S('four-conf-champs-8-at-large-no-cc-bye','none',2027,2026));assert.equal(ctx.__FNOCCGR,false);assert.equal(ctx.__FWKL('cc',E,'Conf Champ Week'),'Conf Champ Week');
// dialog selection logic as patched: auto (R5) and button (R6)
const pick=(s)=>{let r;const A=()=>r='weekSummary',b=()=>r='awards',C=()=>r='ccgSummary';(s!==e.WEEK_CCG+1||s===e.AWARDS_WEEK+1?s!==e.AWARDS_WEEK+1?A():b():C());return r};
ctx.__FAW24=false;assert.equal(pick(15),'ccgSummary');assert.equal(pick(16),'awards');
ctx.__FAW24=true;assert.equal(pick(15),'awards');assert.equal(pick(16),'weekSummary');
console.log('renderer flags / awards week / labels / dialogs: PASS');
ctx.__FFLAGS({leagueSettings:{playoffFormat:'x',ccgUseHighestRanked:'none',ccgHomeGames:{c1:'none',c2:true}},startingYear:2026,mostRecentWeek:{year:2027}});
assert.deepEqual(ctx.__FOFFC,['c1']);assert.equal(ctx.__FNOCCGR,false);
console.log('per-conference flag: PASS');
