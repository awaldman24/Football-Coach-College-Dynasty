// Real stock schedulers (10-team round robin and 2x7 divisions) with the game's own module code.
const fs = require('fs'), vm = require('vm');
const W = process.argv[2];
const M = JSON.parse(fs.readFileSync(W + '/stockmods.json', 'utf8'));
const ctx = { console, Math, Object, Array, String, Number, Set, Map, JSON, Error, Infinity }; ctx.globalThis = ctx; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(W + '/src/hafix.js', 'utf8'), ctx);
const cache = {};
const req = id => {
  id = String(id);
  if (id === '30020') return { GameType: { InDivision: 'in-division', InConference: 'in-conference' } };
  if (cache[id]) return cache[id].exports;
  const m = { exports: {} }; cache[id] = m;
  const f = vm.runInContext('(' + M[id] + ')', ctx);
  f.call({ __importDefault: e => e && e.__esModule ? e : { default: e } }, m, m.exports, req);
  return m.exports;
};
const rr = req('29343').default, two = req('39377').default, C = req('88379');
const U = JSON.parse(fs.readFileSync(W + '/wk/universe.json', 'utf8'));
function streakTeams(g, ids) { let bad = 0; ids.forEach(t => { const L = g.filter(x => x.homeTeamId === t || x.awayTeamId === t).sort((p, q) => p.week - q.week); let run = 0, prev = '', b = false; L.forEach(x => { const s = x.homeTeamId === t ? 'H' : 'A'; run = s === prev ? run + 1 : 1; prev = s; if (run >= 3) b = true; }); if (b) bad++; }); return bad; }
const weeksets = { fluid: [2, 3, 4, 6, 7, 8, 9, 11, 12, 13], '1-4-7': [2, 3, 5, 6, 8, 9, 10, 11, 12, 13] };
let tb = 0, ta = 0, n = 0, fail = 0;
for (const [wn, weeks] of Object.entries(weeksets)) for (const c of U.conferences) {
  const multi = c.divisions.length > 1, ten = !multi && c.divisions[0].teams.length === 10;
  if (!multi && !ten) continue;
  for (let y = 2027; y <= 2036; y++) {
    let g;
    if (ten) { const wk = weeks.slice(); wk.splice(C.SINGLE_DIV_BYE_WEEK - 1, 1); g = rr(c.divisions[0].teams.map(t => ({ id: t.abbreviation, zipcode: t.zipcode })), wk, y); }
    else g = two({ teamDivisionYears: c.divisions[0].teams.map(t => ({ team: { id: t.abbreviation, zipcode: t.zipcode } })) }, { teamDivisionYears: c.divisions[1].teams.map(t => ({ team: { id: t.abbreviation, zipcode: t.zipcode } })) }, weeks, y);
    const ids = c.divisions.flatMap(d => d.teams.map(t => t.abbreviation));
    const before = JSON.parse(JSON.stringify(g));
    const b = streakTeams(g, ids); ctx.__fccdHAFix(g, weeks, c.name + '|' + y, null); const a = streakTeams(g, ids);
    tb += b; ta += a; n++;
    const lastW = Math.max(...before.map(x => x.week)), used = new Set(before.map(x => x.week));
    for (const t of ids) { const w = g.filter(x => x.homeTeamId === t || x.awayTeamId === t).map(x => x.week); if (new Set(w).size !== w.length) { fail++; } const l0 = before.filter(x => (x.homeTeamId === t || x.awayTeamId === t) && x.week >= 11).length, l1 = w.filter(x => x >= 11).length; if (l1 < l0) fail++; }
    if (g.some(x => !used.has(x.week))) fail++;
    if (g.some((x, i) => before[i].week === lastW && x.week !== lastW)) fail++;
    if (y === 2027 || a) console.log(wn.padEnd(6), c.name.padEnd(16), y, 'teams with 3+ streak', b, '->', a);
  }
}
console.log('real stock schedulers:', n, 'schedules; team-seasons with a 3+ streak', tb, '->', ta, 'fails', fail);
