// BCS mode + per-conference title-game switch: sandbox tests on the patched main.js functions.
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const W = process.argv[2];
const parts = fs.readFileSync(W + '/src/extracted2.js', 'utf8').split(/^\/\/== /m).filter(Boolean);
const pick = (name, nth = 0) => parts.filter(p => p.startsWith(name + ' @'))[nth].replace(/^.*\n/, '');
const state = {};
const ctx = {
  console: { log() {} }, Math, Object, Array, Set, Map, JSON, String, Number,
  c: { WEEK_CCG: 14, sortHighToLow: (a, f) => a.sort((x, y) => f(y) - f(x)) },
  P: () => ({ mostRecentWeek: { year: 2005 } }),
  __FN: { getState: (k, d) => k in state ? JSON.parse(JSON.stringify(state[k])) : d, setState: (k, v) => { state[k] = JSON.parse(JSON.stringify(v)) }, add: (y, w, s) => { (state.news = state.news || []).push(s) } },
  X: { createGame: (g, y) => ({ op: 'game', g }) }, nt: { markConferenceWinner: (cid, tid) => ({ op: 'champ', cid, tid }) }, wa: { updateCoachCareerStats: () => ({ op: 'coach' }) }, Ys() {},
  __F24ID: '24-team-23-plus-1',
};
ctx.globalThis = ctx; vm.createContext(ctx);
vm.runInContext('const __FNOCCG_ID="fccd-no-ccg";' + ['__FNOCCG', '__F24CHAMPS', '__F24CONF', '__FCCGOFF', '__FCCGQ', '__FBCSNEWS', '__FBCSON', '__FBCSRNG', '__FBCSCOMP', '__FBCSHUM', '__FBCS', '__FAPPOLL'].map(n => pick(n)).join('\n') +
  '\nglobalThis.T={__FCCGQ,__FBCSCOMP,__FBCS,__FBCSON,__FBCSNEWS};', ctx);
const T = ctx.T;

// ---------- simulated season: 120 FBS teams with known strength, 12 games, a few FCS games ----------
let seed = 11; const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
const ids = [...Array(120).keys()].map(i => 'T' + String(i).padStart(3, '0'));
const str = new Map(ids.map((id, i) => [id, 3 - i * 0.05 + (rnd() - .5) * .3]));   // T000 strongest
const games = [];
for (let wk = 1; wk <= 12; wk++) {
  const pool = ids.slice().sort(() => rnd() - .5);
  for (let k = 0; k + 1 < pool.length; k += 2) {
    let a = pool[k], b = pool[k + 1];
    if (wk === 2 && k < 20) b = 'FCS' + k; // some FCS games
    const sa = str.get(a), sb = str.has(b) ? str.get(b) : -3, pa = 1 / (1 + Math.exp(-(sa - sb) * 1.2));
    const homeWon = rnd() < pa;
    games.push({ homeTeamId: a, awayTeamId: b, homeTeamWon: homeWon, type: 'in-conference', week: wk, neutralSite: false });
  }
}
const W_ = new Map(), L_ = new Map(); games.forEach(g => { const w = g.homeTeamWon ? g.homeTeamId : g.awayTeamId, l = g.homeTeamWon ? g.awayTeamId : g.homeTeamId; W_.set(w, (W_.get(w) || 0) + 1); L_.set(l, (L_.get(l) || 0) + 1) });

// ---------- 1. computers: each tracks true strength, are win-loss only, and disagree a little ----------
{
  const fbs = new Set(ids), G = games.map(g => { const f = x => fbs.has(x) ? x : 'FCS', w = g.homeTeamWon ? g.homeTeamId : g.awayTeamId, l = g.homeTeamWon ? g.awayTeamId : g.homeTeamId; return { w: f(w), l: f(l), h: f(g.homeTeamId), wk: g.week } });
  const pre = Object.fromEntries(ids.map((id, i) => [id, i + 1]));
  const CR = T.__FBCSCOMP(ids, G, pre), keys = Object.keys(CR);
  assert.equal(keys.length, 6, 'six computers');
  const trueRank = new Map(ids.slice().sort((a, b) => str.get(b) - str.get(a)).map((id, k) => [id, k + 1]));
  const spearman = m => { const n = ids.length; let d = 0; ids.forEach(id => { const x = m.get(id) - trueRank.get(id); d += x * x }); return 1 - 6 * d / (n * (n * n - 1)) };
  keys.forEach(k => { const rho = spearman(CR[k]); console.log('   ', k.padEnd(7), 'rank correlation with true strength', rho.toFixed(3)); assert.ok(rho > 0.75, k + ' tracks strength') });
  // an undefeated team should be top-5 in every computer
  const unb = ids.filter(id => !L_.get(id));
  unb.forEach(id => { const avg = keys.reduce((t, k) => t + CR[k].get(id), 0) / keys.length; assert.ok(avg <= 12, `undefeated ${id} average computer rank ${avg}`) });
  // computers must not use margin: games carry no score at all (structural) -> pass
  const top1 = keys.map(k => [...CR[k].entries()].find(([, r]) => r === 1)[0]);
  console.log('1. computers: PASS (undefeated teams:', unb.length, '; #1 by computer:', top1.join(','), ')');
}

// ---------- 2. full BCS week: human poll memory, standings take over at week 8, newspaper ----------
{
  const mkStats = wk => { const e = {}; ids.forEach((id, k) => { const w = games.filter(g => g.week <= wk && ((g.homeTeamWon && g.homeTeamId === id) || (!g.homeTeamWon && g.awayTeamId === id))).length, l = games.filter(g => g.week <= wk && (g.homeTeamId === id || g.awayTeamId === id)).length - w; e[id] = { teamId: id, isOpp: false, wins: w, losses: l, pollVotes: 2000 - k * 10 + w * 40 - l * 60 } }); return e };
  let prevRank = new Map(ids.map((id, k) => [id, k + 1]));
  for (let wk = 0; wk <= 14; wk++) {
    ctx.__FCMG = games.filter(g => g.week <= wk);
    const e = mkStats(wk), res = new Map();
    ctx.__FCMG.filter(g => g.week === wk).forEach(g => { res.set(g.homeTeamId, { won: g.homeTeamWon, opponentRank: prevRank.get(g.awayTeamId) }); res.set(g.awayTeamId, { won: !g.homeTeamWon, opponentRank: prevRank.get(g.homeTeamId) }) });
    T.__FBCS(e, prevRank, res, wk, { fccdBcs: 'on' });
    const ord = Object.values(e).sort((a, b) => b.pollVotes - a.pollVotes).map(q => q.teamId);
    const H = state['bcsh_2005'];
    assert.equal(H.wk, wk);
    if (wk >= 8) {
      const R = state['bcs_2005_' + wk]; assert.ok(R && R.length === 25, 'standings saved wk' + wk);
      assert.deepEqual(ord.slice(0, 25), R.map(r => r.id), 'official top 25 = BCS standings wk' + wk);
      R.forEach(r => { assert.ok(r.avg >= 0 && r.avg <= 1); assert.ok(Math.abs(r.avg - (r.h + r.c + r.comp) / 3) < 2e-4) });
      for (let k = 1; k < 25; k++) assert.ok(R[k - 1].avg >= R[k].avg, 'sorted by BCS average');
    } else {
      assert.ok(!state['bcs_2005_' + wk], 'no BCS standings before week 8');
      const hr = Object.entries(H.cur).sort((a, b) => a[1] - b[1]).map(x => x[0]);
      assert.deepEqual(ord.slice(0, 25), hr.slice(0, 25), 'before week 8 the ranking is the human poll');
    }
    prevRank = new Map(ord.map((id, k) => [id, k + 1]));
  }
  const R14 = state['bcs_2005_14'];
  console.log('2. BCS weeks 0-14: PASS | final BCS top 5:', R14.slice(0, 5).map(r => `${r.id} ${W_.get(r.id) || 0}-${L_.get(r.id) || 0} ${r.avg.toFixed(4)} (H ${r.h.toFixed(3)} C ${r.c.toFixed(3)} comp ${r.comp.toFixed(2)})`).join(' | '));
  // newspaper story
  T.__FBCSNEWS(2005, 14, id => id, id => `${W_.get(id) || 0}-${L_.get(id) || 0}`);
  const st = state.news.pop(); assert.equal(st.label, 'FINAL BCS STANDINGS'); assert.ok(/^1\. /.test(st.subtitle));
  T.__FBCSNEWS(2005, 7, id => id, id => ''); assert.ok(!state.news || !state.news.length, 'no story before week 8');
  assert.equal(T.__FBCSON({ fccdBcs: 'on' }), true); assert.equal(T.__FBCSON({}), false);
  console.log('   newspaper:', st.headline, '|', st.title);
}

// ---------- 3. per-conference title-game switch ----------
{
  const confs = { A: { id: 'cA', name: 'SEC' }, B: { id: 'cB', name: 'Big Ten' } }, CF = {}, rows = [], tm = new Map();
  ['A', 'B'].forEach(k => { for (let j = 0; j < 4; j++) { const id = k + j; CF[id] = confs[k]; tm.set(id, { id, name: id }); rows.push({ teamId: id, isOpp: false, conferenceWins: 4 - j, conferenceLosses: j, wins: 8, losses: j, pollVotes: 100 - j }) } });
  ctx.__FCMG = [];
  const cg = [{ homeTeamId: 'A0', awayTeamId: 'A1', name: 'SEC Championship' }, { homeTeamId: 'B0', awayTeamId: 'B1', name: 'Big Ten Championship' }];
  const r1 = T.__FCCGQ({ ccgHomeGames: { cB: 'none', cA: true } }, cg, rows, CF, tm, 2027, {});
  assert.deepEqual(r1.filter(o => o.op === 'game').map(o => o.g.name), ['SEC Championship'], 'only SEC plays a title game');
  assert.deepEqual(r1.filter(o => o.op === 'champ').map(o => o.tid), ['B0'], 'Big Ten champion from standings');
  const r2 = T.__FCCGQ({ ccgHomeGames: {} }, cg, rows, CF, tm, 2027, {});
  assert.equal(r2.filter(o => o.op === 'game').length, 2); assert.equal(r2.filter(o => o.op === 'champ').length, 0);
  const r3 = T.__FCCGQ({ ccgUseHighestRanked: 'fccd-no-ccg', ccgHomeGames: {} }, cg, rows, CF, tm, 2027, {});
  assert.equal(r3.filter(o => o.op === 'game').length, 0); assert.equal(r3.filter(o => o.op === 'champ').length, 2);
  console.log('3. per-conference switch: PASS');
}
console.log('ALL BCS / PER-CONFERENCE TESTS PASSED');
