// Test: build every conference's schedule with the mod's scheduler for several years, then apply the
// home/road fixer; report streak violations before/after and verify hard constraints.
const fs = require('fs'), vm = require('vm');
const W = process.argv[2];
const ctx = { globalThis: null, console, Math, Object, Array, String, Number, Set, Map, JSON, Error, Infinity };
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(W + '/confsched.js', 'utf8').replace(/},39377[\s\S]*$/, ''), ctx);
vm.runInContext(fs.readFileSync(W + '/src/hafix.js', 'utf8'), ctx);
const U = JSON.parse(fs.readFileSync(W + '/wk/universe.json', 'utf8'));
const abbr2 = {};
U.conferences.forEach(c => c.divisions.forEach(d => d.teams.forEach(t => abbr2[t.abbreviation] = t)));
function streaks(games, teams) {
  let viol = 0, worst = 0, teamsBad = 0;
  teams.forEach(tid => {
    const L = games.filter(g => g.homeTeamId === tid || g.awayTeamId === tid).sort((a, b) => a.week - b.week);
    let run = 0, prev = '', bad = false;
    L.forEach(g => { const s = g.neutralSite ? 'N' : g.homeTeamId === tid ? 'H' : 'A'; if (s === 'N') { run = 0; prev = ''; return; } run = s === prev ? run + 1 : 1; prev = s; worst = Math.max(worst, run); if (run === 3) { viol++; bad = true; } });
    if (bad) teamsBad++;
  });
  return { viol, worst, teamsBad };
}
function check(before, after, teams, lastW, pinFn) {
  // same games, same hosts; one game per team per week; byes kept in weeks >= 11; pinned + last week unchanged
  if (before.length !== after.length) return 'count';
  for (let i = 0; i < after.length; i++) {
    const a = after[i], b = before[i];
    if (a.homeTeamId !== b.homeTeamId || a.awayTeamId !== b.awayTeamId) return 'host changed';
    if ((b.week === lastW || pinFn(b)) && a.week !== b.week) return 'pinned moved ' + b.week;
  }
  for (const t of teams) {
    const wk = after.filter(g => g.homeTeamId === t || g.awayTeamId === t).map(g => g.week);
    if (new Set(wk).size !== wk.length) return 'double booked ' + t;
    const late = w => w >= 11;
    const lb = before.filter(g => (g.homeTeamId === t || g.awayTeamId === t) && late(g.week)).length;
    const la = after.filter(g => (g.homeTeamId === t || g.awayTeamId === t) && late(g.week)).length;
    if (la < lb) return 'new late bye ' + t;
  }
  return null;
}
const weekSets = { early: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13], fluid: [2, 3, 4, 6, 7, 8, 9, 11, 12, 13] };
const tot = { b: 0, a: 0, bt: 0, at: 0, n: 0, fail: 0, ms: 0 };
for (const [wname, weeks] of Object.entries(weekSets)) {
  ctx.__fccdTrad = wname === 'early';
  for (const c of U.conferences) {
    const multi = c.divisions.length > 1;
    if (!ctx.__fccdTrad && (multi || c.divisions[0].teams.length === 10)) continue; // stock path, tested separately
    const tdy = c.divisions.flatMap((d, k) => d.teams.map(t => ({ teamId: t.abbreviation, divisionRivalId: t.rivalAbbreviation, team: { id: t.abbreviation, name: t.name, zipcode: t.zipcode, abbreviation: t.abbreviation }, __div: k })));
    for (let y = 2027; y <= 2036; y++) {
      ctx.__fccdLateTeams = null; ctx.__fccdFree13 = null;
      const t0 = Date.now();
      let g;
      try { g = ctx.__fccdConfSched(tdy, weeks, y, multi); } catch (e) { console.log('sched fail', c.name, y, e.message); continue; }
      const before = JSON.parse(JSON.stringify(g));
      const teams = tdy.map(x => x.teamId);
      const sb = streaks(g, teams);
      const pinFn = x => false; // FIXED pins are passed by the real patch; here only last week pinned
      ctx.__fccdHAFix(g, weeks, c.name + '|' + y, pinFn);
      const ms = Date.now() - t0; tot.ms = Math.max(tot.ms, ms);
      const sa = streaks(g, teams);
      const err = check(before, g, teams, Math.max(...weeks), pinFn);
      if (err) { tot.fail++; console.log('FAIL', wname, c.name, y, err); }
      tot.b += sb.viol; tot.a += sa.viol; tot.bt += sb.teamsBad; tot.at += sa.teamsBad; tot.n++;
      if (y === 2027 || sa.viol) console.log(wname.padEnd(5), c.name.padEnd(16), y, 'teams w/ 3+ streak before', String(sb.teamsBad).padStart(2), 'after', sa.teamsBad, 'longest', sb.worst, '->', sa.worst, ms + 'ms');
    }
  }
}
console.log('TOTAL schedules', tot.n, 'team-seasons with a 3+ streak before', tot.bt, 'after', tot.at, 'fails', tot.fail, 'max ms', tot.ms);
