// End-to-end: patched __fccdConfSched (fix applied inside, with traditional-date pins) on the real conferences.
const fs=require('fs'),vm=require('vm');const W=process.argv[2];
const ctx={console:{log(){}},Math,Object,Array,String,Number,Set,Map,JSON,Error,Infinity};ctx.globalThis=ctx;vm.createContext(ctx);
vm.runInContext(fs.readFileSync(W+'/confsched14.js','utf8'),ctx);
const U=JSON.parse(fs.readFileSync(W+'/wk/universe.json','utf8'));
let bad=0,n=0,pinMoved=0;const FIX={"Florida|Georgia":9,"Oklahoma|Texas":6,"Alabama|Tennessee":7};
for(const [wn,weeks] of Object.entries({early:[4,5,6,7,8,9,10,11,12,13],fluid:[2,3,4,6,7,8,9,11,12,13]})){ctx.__fccdTrad=wn==='early';
 for(const c of U.conferences){const multi=c.divisions.length>1;if(!ctx.__fccdTrad&&(multi||c.divisions[0].teams.length===10))continue;
  const tdy=c.divisions.flatMap((d,k)=>d.teams.map(t=>({teamId:t.abbreviation,divisionRivalId:t.rivalAbbreviation,team:{id:t.abbreviation,name:t.name,zipcode:t.zipcode},__div:k})));
  const nm=Object.fromEntries(tdy.map(x=>[x.teamId,x.team.name]));
  for(let y=2027;y<=2036;y++){ctx.__fccdLateTeams=null;ctx.__fccdFree13=null;const g=ctx.__fccdConfSched(tdy,weeks,y,multi);n++;
   tdy.forEach(x=>{const L=g.filter(q=>q.homeTeamId===x.teamId||q.awayTeamId===x.teamId).sort((a,b)=>a.week-b.week);let run=0,p='';L.forEach(q=>{const s=q.neutralSite?'N':q.homeTeamId===x.teamId?'H':'A';if(s==='N'){run=0;p='';return}run=s===p?run+1:1;p=s;if(run===3)bad++})});
   g.forEach(q=>{const k=[nm[q.homeTeamId],nm[q.awayTeamId]].sort().join('|');if(FIX[k]&&weeks.includes(FIX[k])&&q.week!==FIX[k])pinMoved++});}}}
console.log('e2e patched scheduler:',n,'conference-seasons; 3-game home/road streaks:',bad,'; traditional-date games moved off their week:',pinMoved);
