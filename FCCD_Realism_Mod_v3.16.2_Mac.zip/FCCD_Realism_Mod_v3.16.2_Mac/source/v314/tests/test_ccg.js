// Sandbox tests of the patched v3.14 functions (taken verbatim from the patched main.js).
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const W = process.argv[2];
const parts = fs.readFileSync(W + '/src/extracted.js', 'utf8').split(/^\/\/== /m).filter(Boolean);
const pick = (name, nth = 0) => parts.filter(p => p.startsWith(name + ' @'))[nth].replace(/^.*\n/, '');
const GT = { InConference: 'in-conference', InDivision: 'in-division', ConferenceChampionship: 'conference-championship', PlayoffRoundOf16: 'playoff-round-of-16', PlayoffQuarterfinals: 'playoff-quarterfinals', PlayoffSemifinals: 'playoff-semifinals', PlayoffNCG: 'playoff-ncg', BowlGame: 'bowl-game' };
const ctx = {
  console: { log() {} }, Math, Object, Array, Set, Map, JSON, String, Number,
  c: { GameType: GT, WEEK_CCG: 14, WEEK_PRE_BOWL: 15, WEEK_BOWL_1: 16, WEEK_BOWL_2: 17, WEEK_PLAYOFFS: 18, WEEK_NCG: 19,
       sortHighToLow: (a, f) => a.sort((x, y) => f(y) - f(x)), getNumPlayoffTeams: f => f === '24-team-23-plus-1' ? 24 : 12 },
  nt: { markConferenceWinner: (cid, tid, y) => ({ op: 'champ', cid, tid, y }) },
  wa: { updateCoachCareerStats: (coach, inc) => ({ op: 'coach', coach, inc }) },
  Ia: (ty, a, b) => `${ty} ${a}v${b}`, P: () => ({ mostRecentWeek: { year: 2027 } }),
  __FN: { getState: () => null, setState() {} },
  __F24ID: '24-team-23-plus-1', __CFPB: { Rose: '91103', Sugar: '70116', Orange: '33125', Cotton: '76011', Fiesta: '85004', Peach: '30313' },
};
ctx.globalThis = ctx; vm.createContext(ctx);
vm.runInContext('const __FNOCCG_ID="fccd-no-ccg";' + ['__FNOCCG', '__F24CHAMPS', '__F24CONF', '__FCCGOFF', '__F24SLOT', '__cfpSite', '__F24', '__FCOMMITTEE'].map(n => pick(n)).join('\n') + '\n' + pick('Ys', 1) +
  '\nglobalThis.T={__FNOCCG,__F24CHAMPS,__F24CONF,__F24,__FCOMMITTEE,Ys};', ctx);
const T = ctx.T;

// ---------- league fixture: 4 P4 conferences (prestige 10..7) + 2 G6 (5,4) ----------
function league() {
  const confs = [['SEC', 10], ['Big Ten', 9], ['Big 12', 8], ['ACC', 7], ['Sun Belt', 5], ['American', 4]].map(([n, p], k) => ({ id: 'C' + k, name: n, prestigeLevel: p }));
  const teams = new Map(), CF = {}, rows = [];
  confs.forEach((cf, k) => { for (let j = 0; j < 8; j++) { const id = cf.name.replace(/ /g, '') + j; teams.set(id, { id, name: id, zipcode: '0000' + k }); CF[id] = cf; rows.push({ teamId: id, isOpp: false, wins: 0, losses: 0, conferenceWins: 0, conferenceLosses: 0, pollVotes: 0, strengthOfSchedule: 0, points: 0, yards: 0 }); } });
  return { confs, teams, CF, rows };
}
const row = (L, id) => L.rows.find(r => r.teamId === id);
function setRec(L, id, cw, cl, pv) { const r = row(L, id); r.conferenceWins = cw; r.conferenceLosses = cl; r.wins = cw + 3; r.losses = cl; r.pollVotes = pv; }

// ---------- 1. tiebreakers ----------
{
  const L = league();
  // SEC: SEC0 and SEC1 tied 7-1; SEC1 beat SEC0 head-to-head, SEC0 ranked higher -> SEC1 champion
  setRec(L, 'SEC0', 7, 1, 900); setRec(L, 'SEC1', 7, 1, 800);
  // Big Ten: BigTen0/1/2 tied 6-2, didn't all play each other; vs common opponents BigTen2 best
  setRec(L, 'BigTen0', 6, 2, 950); setRec(L, 'BigTen1', 6, 2, 940); setRec(L, 'BigTen2', 6, 2, 100);
  // Big 12: tied, no h2h, no common opponents -> higher ranking (Big121)
  setRec(L, 'Big120', 8, 1, 300); setRec(L, 'Big121', 8, 1, 700);
  // ACC: Notre Dame-style exclusion: name the best ACC team "Notre Dame"
  L.teams.get('ACC0').name = 'Notre Dame'; setRec(L, 'ACC0', 9, 0, 999); setRec(L, 'ACC1', 7, 2, 500);
  const g = (h, a, hw) => ({ homeTeamId: h, awayTeamId: a, homeTeamWon: hw, type: 'in-conference', week: 5 });
  ctx.__FCMG = [g('SEC1', 'SEC0', true),
    // Big Ten common opponents BigTen5/6/7: BigTen2 3-0, BigTen0 2-1, BigTen1 2-1; BigTen0 beat BigTen1 (but 2 never played them)
    g('BigTen2', 'BigTen5', true), g('BigTen2', 'BigTen6', true), g('BigTen2', 'BigTen7', true),
    g('BigTen0', 'BigTen5', true), g('BigTen0', 'BigTen6', true), g('BigTen0', 'BigTen7', false),
    g('BigTen1', 'BigTen5', true), g('BigTen1', 'BigTen6', false), g('BigTen1', 'BigTen7', true), g('BigTen0', 'BigTen1', true)];
  const ch = T.__F24CHAMPS(L.rows, L.CF, L.teams), by = n => ch[L.confs.find(c => c.name === n).id].id;
  assert.equal(by('SEC'), 'SEC1', 'h2h decides 2-way tie');
  assert.equal(by('Big Ten'), 'BigTen2', 'common opponents decide 3-way tie without full round robin');
  assert.equal(by('Big 12'), 'Big121', 'ranking decides when nothing else does');
  assert.equal(by('ACC'), 'ACC1', 'Notre Dame never ACC champion');
  assert.equal(Object.keys(ch).length, 6, 'one champion per conference');
  // 3-way round robin cycle (A>B, B>C, C>A) -> falls to common opponents then ranking
  const L2 = league(); setRec(L2, 'SEC0', 6, 2, 100); setRec(L2, 'SEC1', 6, 2, 300); setRec(L2, 'SEC2', 6, 2, 200);
  ctx.__FCMG = [g('SEC0', 'SEC1', true), g('SEC1', 'SEC2', true), g('SEC2', 'SEC0', true)];
  assert.equal(T.__F24CHAMPS(L2.rows, L2.CF, L2.teams)[L2.confs[0].id].id, 'SEC1', '3-way h2h cycle -> ranking');
  // coach credit: champion's head coach gets ccgWins +1
  ctx.__FCMG = [];
  const ops = T.__F24CONF(L.rows, L.CF, L.teams, 2027, { SEC0: 'coachA', Big121: 'coachB' });
  const coachOps = ops.filter(o => o.op === 'coach'), champOps = ops.filter(o => o.op === 'champ');
  assert.equal(champOps.length, 6); assert.equal(coachOps.length, 2);
  assert.deepEqual(JSON.parse(JSON.stringify(coachOps[0].inc)), { ccgWins: { increment: 1 } });
  console.log('1. tiebreakers + coach credit: PASS');
}

// ---------- 2. switch ----------
assert.equal(T.__FNOCCG({ ccgUseHighestRanked: 'fccd-no-ccg', playoffFormat: 'x' }), true);
assert.equal(T.__FNOCCG({ ccgUseHighestRanked: 'none', playoffFormat: '24-team-23-plus-1' }), true);
assert.equal(T.__FNOCCG({ ccgUseHighestRanked: 'none', playoffFormat: 'four-conf' }), false);
console.log('2. switch: PASS');

// ---------- 3. 24-team field, seeding and calendar ----------
{
  const L = league(); ctx.__FCMG = [];
  // ranking: 48 teams by pollVotes (index order), but make ACC champion ACC5 ranked 40th and American champ American3 ranked 30th
  L.rows.forEach((r, k) => { r.pollVotes = 10000 - k * 10; r.conferenceWins = 4; r.conferenceLosses = 4; });
  const champ = (id, pv) => { const r = row(L, id); r.conferenceWins = 8; r.conferenceLosses = 0; r.pollVotes = pv; };
  champ('SEC0', 20000); champ('BigTen0', 19000); champ('Big120', 18000); champ('ACC5', 9000 - 400); // ACC5 ~ rank 40
  champ('SunBelt2', 9000 - 700); champ('American3', 9000 - 200); // American3 better-ranked G6 champion
  ctx.__fccdConfByTeam = L.CF;
  const R = T.__F24({}, 2027, 13, L.rows, {}, L.teams, [], []);
  const f = R.playoffTeams;
  assert.equal(f.length, 24, '24 teams');
  assert.ok(f.includes('ACC5'), 'P4 champion ranked outside top 24 gets in');
  assert.ok(f.includes('American3') && !f.includes('SunBelt2'), 'best-ranked G6 champion in, other G6 champion out');
  const ranked = L.rows.slice().sort((a, b) => b.pollVotes - a.pollVotes).map(r => r.teamId);
  const pos = id => ranked.indexOf(id);
  for (let k = 1; k < 24; k++) assert.ok(pos(f[k - 1]) < pos(f[k]), 'straight seeding by ranking');
  const atLarge = f.filter(id => !['SEC0', 'BigTen0', 'Big120', 'ACC5', 'American3'].includes(id));
  assert.equal(atLarge.length, 19, '19 at-large');
  assert.ok(R.playoffGames.every(g => g.week === 15), 'first round in week 15');
  assert.equal(R.playoffGames.length, 8);
  const g1 = R.playoffGames.find(g => g.name.includes('9 v 24'));
  assert.equal(g1.homeTeamId, f[8]); assert.equal(g1.awayTeamId, f[23]); assert.equal(g1.neutralSite, false);
  // week 14: bowls only (exclude all 24), no games
  const seeds = {}; f.forEach((id, k) => seeds[id] = { playoffSeed: k + 1 });
  const R14 = T.__F24({}, 2027, 14, L.rows, seeds, L.teams, [], R.playoffGames.map(g => ({ ...g })));
  assert.equal(R14.playoffGames.length, 0); assert.equal(R14.bowlExclude.length, 24);
  // week 15 results -> second round week 16 at seeds 1-8
  const played = R.playoffGames.map(g => ({ game: { ...g, homeTeamWon: true } }));
  const R15 = T.__F24({}, 2027, 15, L.rows, seeds, L.teams, played, R.playoffGames);
  assert.equal(R15.playoffGames.length, 8); assert.ok(R15.playoffGames.every(g => g.week === 16 && seeds[g.homeTeamId].playoffSeed <= 8));
  const r2 = R15.playoffGames.find(g => seeds[g.homeTeamId].playoffSeed === 1);
  assert.equal(seeds[r2.awayTeamId].playoffSeed, 16, '#1 hosts the 16/17 winner');
  // idempotent: re-running week 15 once round two exists returns nothing
  assert.equal(T.__F24({}, 2027, 15, L.rows, seeds, L.teams, played, R.playoffGames.concat(R15.playoffGames)), null);
  // week 16 results -> quarterfinals week 17 at New Year's Six sites
  const p2 = R15.playoffGames.map(g => ({ game: { ...g, homeTeamWon: true } }));
  const R16 = T.__F24({}, 2027, 16, L.rows, seeds, L.teams, p2, R.playoffGames.concat(R15.playoffGames));
  assert.equal(R16.playoffGames.length, 4); assert.ok(R16.playoffGames.every(g => g.week === 17 && g.neutralSite && /Bowl/.test(g.name)));
  console.log('3. 24-team field / seeding / calendar: PASS', '| field:', f.slice(0, 4).join(','), '... #24', f[23]);
}

// ---------- 4. committee: standings champion bump only with titles games off ----------
{
  const run = st => {
    const L = league(); ctx.__FCMG = []; ctx.__FOPP = {}; ctx.__FACC = {}; ctx.__FCONF0 = L.CF; ctx.__fccdTeams = L.teams;
    L.rows.forEach((r, k) => { r.pollVotes = 5000 - k * 50; r.wins = 9; r.losses = 3; r.conferenceWins = 5; r.conferenceLosses = 3; r.strengthOfSchedule = 1000; });
    const r5 = row(L, 'SEC5'); r5.conferenceWins = 8; r5.conferenceLosses = 0;
    const e = {}; L.rows.forEach(r => e[r.teamId] = { ...r });
    T.__FCOMMITTEE(e, 13, st); return e.SEC5.pollVotes - e.SEC4.pollVotes;
  };
  const off = run({ playoffFormat: 'four-conf', ccgUseHighestRanked: 'fccd-no-ccg' }), on = run({ playoffFormat: 'four-conf', ccgUseHighestRanked: 'none' });
  assert.ok(off > on, 'standings champion gets a bump when title games are off');
  const conf = L0 => L0; const perConf = run({ playoffFormat: 'four-conf', ccgUseHighestRanked: 'none', ccgHomeGames: { C0: 'none' } }), otherConf = run({ playoffFormat: 'four-conf', ccgUseHighestRanked: 'none', ccgHomeGames: { C1: 'none' } });
  assert.ok(perConf > on, 'SEC title game off -> SEC standings champion bumped'); assert.equal(otherConf, on, 'another conference off -> SEC unaffected');
  console.log('4. committee champion bump: PASS (gap vs neighbor', on, '->', off + ')');
}
console.log('ALL TESTS PASSED');
