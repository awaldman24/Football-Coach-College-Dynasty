#!/usr/bin/env python3
"""Minimal asar reader / repacker. Keeps 'unpacked' entries as-is in the header.
usage:
  asartool.py extract ASAR OUTDIR            # extracts packed files only
  asartool.py repack ASAR OUT REPL...        # REPL = archive/path=localfile
"""
import json, struct, sys, os

def read(path):
    with open(path, 'rb') as f:
        data = f.read()
    # pickle: [4: size=4][4: header pickle size]  then header pickle: [4 payload][4 strlen][json][pad]
    hp_size = struct.unpack_from('<I', data, 4)[0]
    strlen = struct.unpack_from('<I', data, 12)[0]
    hjson = data[16:16 + strlen].decode('utf-8')
    header = json.loads(hjson)
    base = 8 + hp_size
    return data, header, base

def walk(node, prefix=''):
    for name, ent in node.get('files', {}).items():
        p = prefix + '/' + name
        if 'files' in ent:
            yield from walk(ent, p)
        else:
            yield p, ent

def extract(asar, out):
    data, header, base = read(asar)
    n = 0
    for p, ent in walk(header):
        if ent.get('unpacked') or 'link' in ent:
            continue
        off = int(ent['offset']); sz = ent['size']
        dst = os.path.join(out, p.lstrip('/'))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, 'wb') as f:
            f.write(data[base + off: base + off + sz])
        n += 1
    print('extracted', n)

def repack(asar, out, repls):
    data, header, base = read(asar)
    rep = {}
    for r in repls:
        k, v = r.split('=', 1)
        rep['/' + k.lstrip('/')] = open(v, 'rb').read()
    chunks = []; cur = 0
    seen = set()
    for p, ent in walk(header):
        if ent.get('unpacked') or 'link' in ent:
            continue
        if p in rep:
            body = rep[p]; seen.add(p)
            import hashlib
            bs = 4194304
            ent['integrity'] = {'algorithm': 'SHA256', 'hash': hashlib.sha256(body).hexdigest(),
                                'blockSize': bs,
                                'blocks': [hashlib.sha256(body[i:i + bs]).hexdigest() for i in range(0, max(len(body), 1), bs)]}
        else:
            off = int(ent['offset']); body = data[base + off: base + off + ent['size']]
        ent['offset'] = str(cur); ent['size'] = len(body)
        chunks.append(body); cur += len(body)
    missing = set(rep) - seen
    if missing:
        sys.exit('not found in archive: %s' % missing)
    hj = json.dumps(header, separators=(',', ':')).encode('utf-8')
    strlen = len(hj)
    pad = (4 - strlen % 4) % 4
    payload = struct.pack('<I', strlen) + hj + b'\0' * pad
    hpickle = struct.pack('<I', len(payload)) + payload
    head = struct.pack('<I', 4) + struct.pack('<I', len(hpickle))
    with open(out, 'wb') as f:
        f.write(head + hpickle)
        for c in chunks:
            f.write(c)
    print('wrote', out, os.path.getsize(out))

if __name__ == '__main__':
    if sys.argv[1] == 'extract':
        extract(sys.argv[2], sys.argv[3])
    else:
        repack(sys.argv[2], sys.argv[3], sys.argv[4:])
