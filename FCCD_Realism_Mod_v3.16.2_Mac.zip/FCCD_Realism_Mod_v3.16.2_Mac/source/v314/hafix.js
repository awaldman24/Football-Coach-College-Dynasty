// FCCD v3.14: home/road streak limiter for conference schedules.
// __fccdHAFix(games, weeks, seed, isPinned) reorders WHICH WEEK each conference game is played in so no team
// plays more than 2 conference home games (or 2 road games) in a row. Who hosts each game never changes
// (home-and-home series and yearly alternation stay intact). Hard rules kept:
//  - each team still plays at most one game per week, and every team keeps its bye weeks (except whole-week swaps
//    between two early weeks, which only move byes among weeks before week 11 -> still no late byes);
//  - pinned games (traditional dates such as Florida-Georgia, Red River) and the final conference week never move.
// Neutral-site games end a streak. Byes are skipped (H, bye, H counts as two in a row).
function __fccdHAFix(games, weeks, seed, isPinned, pass, deadline) {
  try {
    if (!games || games.length < 4) return games;
    if (!deadline) deadline = Date.now() + 1500; // at most about 1.5 seconds per conference
    // only weeks that already hold conference games (a conference-wide bye week stays empty)
    var used0 = {}; games.forEach(function (g) { used0[g.week] = 1; });
    var W = weeks.filter(function (w) { return used0[w]; }).sort(function (a, b) { return a - b; });
    if (W.length < 3) return games;
    var lastW = W[W.length - 1];
    var LATE = 11;
    var hsh = 2166136261; seed = String(seed); for (var q = 0; q < seed.length; q++) { hsh ^= seed.charCodeAt(q); hsh = Math.imul(hsh, 16777619); }
    var st = hsh >>> 0;
    function rnd() { st |= 0; st = (st + 0x6D2B79F5) | 0; var t = Math.imul(st ^ (st >>> 15), 1 | st); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
    var pin = games.map(function (g) { return g.week === lastW || W.indexOf(g.week) < 0 || !!(isPinned && isPinned(g)); });
    var byTeam = {};
    games.forEach(function (g, i) { (byTeam[g.homeTeamId] = byTeam[g.homeTeamId] || []).push(i); (byTeam[g.awayTeamId] = byTeam[g.awayTeamId] || []).push(i); });
    function cost(tid) {
      var L = byTeam[tid].slice().sort(function (a, b) { return games[a].week - games[b].week; });
      var c = 0, run = 0, prev = "";
      for (var k = 0; k < L.length; k++) {
        var g = games[L[k]], s = g.neutralSite ? "N" : (g.homeTeamId === tid ? "H" : "A");
        if (s === "N") { run = 0; prev = ""; continue; }
        run = s === prev ? run + 1 : 1; prev = s;
        if (run >= 3) c += run === 3 ? 10 : 4; // first violation weighs most
      }
      return c;
    }
    var teams = Object.keys(byTeam);
    var tc = {}; var total = 0; teams.forEach(function (t) { tc[t] = cost(t); total += tc[t]; });
    if (total === 0) return games;
    var movable = W.filter(function (w) { return w !== lastW; });
    function teamsOf(idx) { var s = {}; idx.forEach(function (i) { s[games[i].homeTeamId] = 1; s[games[i].awayTeamId] = 1; }); return Object.keys(s); }
    function apply(idx, newWeeks) {
      var old = idx.map(function (i) { return games[i].week; });
      idx.forEach(function (i, k) { games[i].week = newWeeks[k]; });
      return old;
    }
    function tryMove(idx, newWeeks, temp) {
      var ts = teamsOf(idx), before = 0, after = 0;
      ts.forEach(function (t) { before += tc[t]; });
      var old = apply(idx, newWeeks);
      var nc = {}; ts.forEach(function (t) { nc[t] = cost(t); after += nc[t]; });
      var d = after - before;
      if (d <= 0 || rnd() < Math.exp(-d / temp)) { ts.forEach(function (t) { tc[t] = nc[t]; }); total += d; return true; }
      apply(idx, old); return false;
    }
    var ITER = 90000, PER = 6000, best = total, bestWk = games.map(function (g) { return g.week; });
    for (var it = 0; it < ITER && best > 0; it++) {
      if ((it & 1023) === 0 && Date.now() > deadline) break;
      if (total < best) { best = total; bestWk = games.map(function (g) { return g.week; }); }
      var temp = Math.max(0.05, 3 * (1 - (it % PER) / PER)); // reheats every PER moves
      var c1 = movable[Math.floor(rnd() * movable.length)], c2 = movable[Math.floor(rnd() * movable.length)];
      if (c1 === c2) continue;
      var inPair = []; games.forEach(function (g, i) { if (g.week === c1 || g.week === c2) inPair.push(i); });
      if (rnd() < 0.15) {
        // whole-week swap: only between two early weeks, or two late weeks where nobody has a bye
        if (inPair.some(function (i) { return pin[i]; })) continue;
        var early = c1 < LATE && c2 < LATE;
        if (!early) {
          var cnt = {}; inPair.forEach(function (i) { var w = games[i].week; cnt[w] = (cnt[w] || 0) + 2; });
          if (cnt[c1] !== teams.length || cnt[c2] !== teams.length) continue;
        }
        tryMove(inPair, inPair.map(function (i) { return games[i].week === c1 ? c2 : c1; }), temp);
        continue;
      }
      // Kempe cycle: alternating c1/c2 games where every team in the component plays in both weeks
      var adj = {}; inPair.forEach(function (i) { var g = games[i]; (adj[g.homeTeamId] = adj[g.homeTeamId] || []).push(i); (adj[g.awayTeamId] = adj[g.awayTeamId] || []).push(i); });
      var start = inPair[Math.floor(rnd() * inPair.length)];
      if (start === undefined) continue;
      // open chains (a team with a bye in one of the two weeks) move that bye, so they're only allowed when
      // both weeks are before week 11
      var openOK = c1 < LATE && c2 < LATE;
      var seen = {}, comp = [], stack = [start], ok = true;
      while (stack.length) {
        var gi = stack.pop(); if (seen[gi]) continue; seen[gi] = 1; comp.push(gi);
        if (pin[gi]) { ok = false; break; }
        [games[gi].homeTeamId, games[gi].awayTeamId].forEach(function (t) {
          if (adj[t].length !== 2 && !openOK) ok = false;
          adj[t].forEach(function (j) { if (!seen[j]) stack.push(j); });
        });
        if (!ok) break;
      }
      if (!ok || comp.length < 2) continue;
      tryMove(comp, comp.map(function (i) { return games[i].week === c1 ? c2 : c1; }), temp);
    }
    if (total < best) { best = total; bestWk = games.map(function (g) { return g.week; }); }
    games.forEach(function (g, i) { g.week = bestWk[i]; });
    // not clean yet: search again from the best schedule with a new seed (up to 4 passes in all)
    if (best > 0 && (pass || 0) < 3 && Date.now() < deadline) return __fccdHAFix(games, weeks, seed + "|r", isPinned, (pass || 0) + 1, deadline);
    return games;
  } catch (z) { console.log(">>> FCCD home/road fix error", z); return games; }
}
globalThis.__fccdHAFix = __fccdHAFix;
