const __FNOCCG_ID="fccd-no-ccg";
// v3.14: conference title games are off when the "CCG format" setting is "No conference title games", and always with the 24-team playoff
function __FNOCCG(u){try{return!!u&&(u.ccgUseHighestRanked===__FNOCCG_ID||u.playoffFormat===__F24ID)}catch(z){return!1}}
// v3.14: standings champion per conference. Best conference win %; ties: head-to-head among the tied teams (only when every
// pair played), record vs common conference opponents, committee/poll ranking, then a fixed coin flip. Ties are re-run on the
// smaller group after each step. Notre Dame is never ACC champion; UConn is independent.
function __F24CHAMPS(st,T,tm){
 const G=(globalThis.__FCMG||[]).filter(g=>"in-conference"===g.type||"in-division"===g.type),res=new Map,add=(a,b,w)=>{res.has(a)||res.set(a,[]);res.get(a).push({o:b,w})};
 G.forEach(g=>{add(g.homeTeamId,g.awayTeamId,!!g.homeTeamWon);add(g.awayTeamId,g.homeTeamId,!g.homeTeamWon)});
 const by={};st.filter(r=>!r.isOpp).forEach(r=>{const cf=T[r.teamId];if(!cf||tm.get(r.teamId)?.isFcs)return;const nm=tm.get(r.teamId)?.name;if("ACC"===cf.name&&"Notre Dame"===nm)return;if("UConn"===nm)return;(by[cf.id]=by[cf.id]||{cf,rows:[]}).rows.push(r)});
 const pct=r=>{const g=r.conferenceWins+r.conferenceLosses;return g?r.conferenceWins/g:0},hs=s=>{let x=2166136261;for(let i=0;i<s.length;i++){x^=s.charCodeAt(i);x=Math.imul(x,16777619)}return x>>>0},narrow=(arr,f)=>{const v=arr.map(f),m=Math.max(...v);return arr.filter((r,i)=>Math.abs(v[i]-m)<1e-9)},vs=(a,b)=>(res.get(a)||[]).filter(x=>x.o===b),best={};
 Object.entries(by).forEach(([cid,{cf,rows}])=>{let g=narrow(rows,pct);
  for(let guard=0;g.length>1&&guard<8;guard++){const n0=g.length,ids=new Set(g.map(r=>r.teamId));
   if(g.every(a=>g.every(b=>a===b||vs(a.teamId,b.teamId).length>0))){g=narrow(g,r=>{let W=0,L=0;g.forEach(o=>{o!==r&&vs(r.teamId,o.teamId).forEach(x=>x.w?W++:L++)});return W+L?W/(W+L):0});if(g.length<n0)continue}
   const op=r=>new Set((res.get(r.teamId)||[]).map(x=>x.o)),cs=new Set([...op(g[0])].filter(o=>!ids.has(o)&&g.every(r=>op(r).has(o))));
   if(cs.size){g=narrow(g,r=>{let W=0,L=0;(res.get(r.teamId)||[]).forEach(x=>{cs.has(x.o)&&(x.w?W++:L++)});return W+L?W/(W+L):0});if(g.length<n0)continue}
   g=narrow(g,r=>r.pollVotes);if(g.length<n0)continue;break}
  g.length>1&&g.sort((p,q)=>hs(p.teamId+"|"+cid)-hs(q.teamId+"|"+cid));g.length&&(best[cid]={id:g[0].teamId,cf})});
 return best}
// marks the standings champions; with hc (team -> head coach map) the champion's head coach is credited with a conference title (ccgWins)
function __F24CONF(st,T,tm,y,hc,only){try{const ch=Object.fromEntries(Object.entries(__F24CHAMPS(st,T,tm)).filter(([cid])=>!only||only.has(String(cid)))),ops=Object.entries(ch).map(([cid,b])=>nt.markConferenceWinner(cid,b.id,y));if(hc){const a={};Object.values(ch).forEach(b=>Ys(b.id,"ccgWins",hc,a));Object.entries(a).forEach(([e,t])=>ops.push(wa.updateCoachCareerStats(e,t)))}console.log(">>> FCCD standings champions:",Object.values(ch).map(b=>b.cf.name+"="+(tm.get(b.id)?.name??b.id)).join(", "));return ops}catch(z){console.log(">>> ERROR fccd standings champions",z);return[]}}
// v3.14: per-conference switch: Customization > postseason locations > a conference's CCG location "No title game" (ccgHomeGames[id]="none")
function __FCCGOFF(u){const s=new Set;try{Object.entries(u?.ccgHomeGames||{}).forEach(([k,v])=>{"none"===v&&s.add(String(k))})}catch(z){}return s}
function __FCCGQ(u,cg,I,T,tm,y,hc){if(__FNOCCG(u))return __F24CONF(I,T,tm,y,hc);const off=__FCCGOFF(u);if(!off.size)return cg.map(g=>X.createGame(g,y));return[...cg.filter(g=>!off.has(String(T[g.homeTeamId]?.id))).map(g=>X.createGame(g,y)),...__F24CONF(I,T,tm,y,hc,off)]}
// BCS standings in the newspaper (weeks 8 through the final standings)
function __FBCSNEWS(t,a,nm,rec){try{if(a<8||a>c.WEEK_CCG)return;const R=__FN.getState("bcs_"+t+"_"+a,null);if(!R||R.length<12)return;const fin=a===c.WEEK_CCG,f4=x=>x.toFixed(4).replace(/^0/,"");__FN.add(t,a,{label:fin?"FINAL BCS STANDINGS":"BCS STANDINGS",score:fin?985:900,teams:R.map(r=>r.id),headline:fin?"Final BCS standings":`BCS standings after Week ${a}`,title:`${nm(R[0].id)} is No. 1 in the BCS`+(fin?"":`, ${nm(R[1].id)} No. 2`),subtitle:R.map((r,k)=>`${k+1}. ${nm(r.id)} (${rec(r.id)}) ${f4(r.avg)}`).join(" · ")+" · BCS average = (Harris + Coaches + computers) / 3."})}catch(z){console.log(">>> FCCD BCS news error",z)}}
