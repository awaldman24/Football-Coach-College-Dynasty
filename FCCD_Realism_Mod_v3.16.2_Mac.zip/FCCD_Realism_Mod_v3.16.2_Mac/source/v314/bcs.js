// v3.14: BCS standings mode (League setting "BCS rankings" on). Human poll keeps running AP-style all season (its own week-to-week
// memory in the mod store); from week 8 through the final standings the official ranking is the BCS formula:
// (Harris % + Coaches % + computer %) / 3, computers = 6 win-loss-only systems, highest and lowest dropped (2004-13 rules).
function __FBCSON(st){try{return!!st&&"on"===st.fccdBcs}catch(z){return!1}}
function __FBCSRNG(seed){let h=2166136261;seed=String(seed);for(let i=0;i<seed.length;i++){h^=seed.charCodeAt(i);h=Math.imul(h,16777619)}let a=h>>>0;return()=>{a|=0;a=a+1831565813|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
// games: [{w,l,h}] h = home team id or null (neutral). ids: FBS team ids; "FCS" is one pooled opponent (as the Colley matrix did).
function __FBCSCOMP(ids,games,pre){
 const N=[...ids,"FCS"],ix=new Map(N.map((id,k)=>[id,k])),n=N.length,W=new Array(n).fill(0),L=new Array(n).fill(0),G=[];
 games.forEach(g=>{const a=ix.get(g.w),b=ix.get(g.l);if(a===void 0||b===void 0||a===b)return;W[a]++;L[b]++;G.push([a,b,g.h===g.w?1:g.h===g.l?-1:0,g.wk??0])});
 const nb=Array.from({length:n},()=>new Map);G.forEach(([a,b])=>{nb[a].set(b,(nb[a].get(b)||0)+1);nb[b].set(a,(nb[b].get(a)||0)+1)});
 const gs=k=>W[k]+L[k],out={};
 // 1. Colley matrix (exact method): (2+n_i) r_i - sum n_ij r_j = 1 + (w_i - l_i)/2
 {const r=new Array(n).fill(.5);for(let it=0;it<400;it++)for(let i=0;i<n;i++){let s=1+(W[i]-L[i])/2;nb[i].forEach((c,j)=>{s+=c*r[j]});r[i]=s/(2+gs(i))}out.colley=r}
 // 2. Wolfe: Bradley-Terry maximum likelihood (MM algorithm), regularized by one win and one loss against an average team
 {let p=new Array(n).fill(1);for(let it=0;it<500;it++){const q=p.slice();for(let i=0;i<n;i++){let d=2/(p[i]+1);nb[i].forEach((c,j)=>{d+=c/(p[i]+p[j])});q[i]=(W[i]+1)/d}const gm=Math.exp(q.reduce((s,x)=>s+Math.log(x),0)/n);p=q.map(x=>x/gm)}out.wolfe=p}
 // 3. Sagarin ELO-chess style: ratings whose logistic expectations reproduce results (home field 55 pts), prior = a draw vs a 1500 team
 {const R=new Array(n).fill(1500),E=(d)=>1/(1+Math.pow(10,-d/400));for(let it=0;it<300;it++){const gr=new Array(n).fill(0);for(let i=0;i<n;i++)gr[i]+=.5-E(R[i]-1500);G.forEach(([a,b,h])=>{const e=E(R[a]-R[b]+55*h);gr[a]+=1-e;gr[b]-=1-e});const k=Math.max(4,40*(1-it/300));for(let i=0;i<n;i++)R[i]+=k*gr[i]/Math.max(1,gs(i)/4)}out.elo=R}
 // 4. Massey (win-loss only): least squares with each game = +1 for the winner, home field term
 {const r=new Array(n).fill(0),T=Array.from({length:n},()=>[]);G.forEach(([a,b,h])=>{T[a].push([b,1,h]);T[b].push([a,-1,-h])});let hf=0;for(let it=0;it<400;it++){for(let i=0;i<n;i++){let s=0;T[i].forEach(([o,y,h])=>{s+=r[o]+y-hf*h});r[i]=T[i].length?s/(T[i].length+.5):0}let hs=0,hc=0;G.forEach(([a,b,h])=>{h&&(hs+=h*(1-(r[a]-r[b])),hc++)});hf=hc?Math.max(0,Math.min(.3,hs/hc)):0}out.massey=r}
 // 5. Anderson & Hester style: record and schedule strength (opponents' and opponents' opponents' records), no margin
 {const wp=k=>gs(k)?W[k]/gs(k):.5,owp=i=>{let s=0,c=0;G.forEach(([a,b])=>{a===i?(s+=gs(b)>1?(W[b])/(gs(b)-1):.5,c++):b===i&&(s+=gs(a)>1?(W[a]-1)/(gs(a)-1):.5,c++)});return c?s/c:.5},O=N.map((_,i)=>owp(i)),oowp=i=>{let s=0,c=0;nb[i].forEach((m,j)=>{s+=m*O[j];c+=m});return c?s/c:.5};out.ah=N.map((_,i)=>.35*wp(i)+.45*O[i]+.2*oowp(i))}
 // 6. Billingsley style: progressive, starts from the preseason order and moves week by week (beating a better team pays more)
 {const R=N.map((id,i)=>id==="FCS"?20:50+30*(1-Math.min(1,(pre?.[id]??90)/90)));G.slice().sort((x,y)=>x[3]-y[3]).forEach(([a,b,h])=>{const e=1/(1+Math.pow(10,(R[b]-R[a])/25)),g=12*(1-e)+2+(h===-1?1:0);R[a]+=g;N[b]!=="FCS"&&(R[b]-=.75*(12*(1-e))+1);N[a]==="FCS"&&(R[a]=20)});out.bill=R}
 const ranks={};Object.entries(out).forEach(([k,v])=>{const o=ids.slice().sort((x,y)=>v[ix.get(y)]-v[ix.get(x)]||(W[ix.get(y)]-L[ix.get(y)])-(W[ix.get(x)]-L[ix.get(x)]));ranks[k]=new Map(o.map((id,r)=>[id,r+1]))});
 return ranks}
// human polls: Harris (114 voters) and Coaches (59) ballots drawn around the human poll ranking; returns share of max points
function __FBCSHUM(order,seed,voters){const rnd=__FBCSRNG(seed),gauss=()=>{let u=0,v=0;while(!u)u=rnd();while(!v)v=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)},pts=new Map,top=order.slice(0,45);
 for(let k=0;k<voters;k++){const b=top.map((id,r)=>[id,-(r+1)+gauss()*(.9+.07*(r+1))]).sort((x,y)=>y[1]-x[1]).slice(0,25);b.forEach(([id],r)=>pts.set(id,(pts.get(id)||0)+25-r))}
 const mx=voters*25,sh=new Map;order.forEach(id=>sh.set(id,(pts.get(id)||0)/mx));return sh}
function __FBCS(e,prevDB,res,wk,st){try{
 const yr=P().mostRecentWeek.year,hk="bcsh_"+yr,H=__FN.getState(hk,null);
 // 1) human poll, AP-style all season, using its own previous week (not last week's BCS order)
 let prev=prevDB;if(wk>=9&&H){const pv=H.wk<wk?H.cur:H.wk===wk?H.prev:null;pv&&(prev=new Map(Object.entries(pv)))}
 __FAPPOLL(e,prev,res,wk,!0);
 const all=Object.values(e).filter(q=>!q.isOpp).sort((p,q)=>q.pollVotes-p.pollVotes),order=all.map(q=>q.teamId),cur={};order.forEach((id,k)=>cur[id]=k+1);
 __FN.setState(hk,{wk,cur,prev:H?(H.wk===wk?H.prev:H.cur):null,first:H?.first??cur});
 if(wk<8||wk>c.WEEK_CCG)return;
 // 2) computers (win-loss only)
 const fbs=new Set(order),games=(globalThis.__FCMG||[]).filter(g=>!/playoff|bowl/.test(g.type||"")).map(g=>{const w=g.homeTeamWon?g.homeTeamId:g.awayTeamId,l=g.homeTeamWon?g.awayTeamId:g.homeTeamId,f=x=>fbs.has(x)?x:"FCS";return{w:f(w),l:f(l),h:g.neutralSite?null:f(g.homeTeamId),wk:g.week}});
 const CR=__FBCSCOMP(order,games,H?.first??cur),keys=Object.keys(CR);
 // 3) BCS average
 const harris=__FBCSHUM(order,`h|${yr}|${wk}`,114),coaches=__FBCSHUM(order,`c|${yr}|${wk}`,59),rows=order.map(id=>{const p=keys.map(k=>{const r=CR[k].get(id);return r<=25?26-r:0}).sort((x,y)=>x-y),comp=p.slice(1,5).reduce((s,x)=>s+x,0)/100,h=harris.get(id),co=coaches.get(id);return{id,h,co,comp,avg:(h+co+comp)/3,cr:keys.map(k=>CR[k].get(id))}});
 rows.sort((x,y)=>y.avg-x.avg||cur[x.id]-cur[y.id]);
 const ranked=rows.filter(r=>r.avg>0).map(r=>r.id),rest=order.filter(id=>!ranked.includes(id)),final=[...ranked,...rest],vals=all.map(q=>q.pollVotes);for(let k=1;k<vals.length;k++)vals[k]>=vals[k-1]&&(vals[k]=vals[k-1]-1);
 final.forEach((id,k)=>{e[id]={...e[id],pollVotes:vals[k]}});
 __FN.setState("bcs_"+yr+"_"+wk,rows.slice(0,25).map(r=>({id:r.id,avg:+r.avg.toFixed(4),h:+r.h.toFixed(4),c:+r.co.toFixed(4),comp:+r.comp.toFixed(2),cr:r.cr})));
 console.log(">>> FCCD BCS standings wk"+wk+":",rows.slice(0,10).map((r,k)=>k+1+" "+r.id.slice(0,6)+" "+r.avg.toFixed(4)).join(", "))
}catch(z){console.log(">>> FCCD BCS error",z)}}
