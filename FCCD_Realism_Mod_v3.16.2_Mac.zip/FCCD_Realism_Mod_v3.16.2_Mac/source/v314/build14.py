#!/usr/bin/env python3
"""FCCD Realism Mod v3.14 build: patches main.js and renderer.js extracted from the v3.13 app.asar.
usage: build14.py EXTRACT_DIR SRC_DIR   (writes patched files in place under EXTRACT_DIR)"""
import sys, os, re
EX, SRC = sys.argv[1], sys.argv[2]
MAIN = os.path.join(EX, 'dist/main/main.js')
REND = os.path.join(EX, 'dist/renderer/renderer.js')
rd = lambda p: open(p, encoding='utf-8').read()
m = rd(MAIN); r = rd(REND)
src = lambda n: rd(os.path.join(SRC, n))

def rep(s, old, new, label, count=1):
    n = s.count(old)
    if n != count:
        sys.exit(f'PATCH FAIL {label}: found {n}, expected {count}')
    print('ok', label)
    return s.replace(old, new)

def cut_function(s, name):
    """return (start, end) of 'function NAME(' declaration by brace matching (code has no braces in strings that matter here)"""
    i = s.find('function ' + name + '(')
    if i < 0 or s.find('function ' + name + '(', i + 1) >= 0:
        sys.exit('function not unique: ' + name)
    j = s.find('{', i); depth = 0; k = j
    in_str = None; esc = False
    while True:
        ch = s[k]
        if in_str:
            if esc: esc = False
            elif ch == '\\': esc = True
            elif ch == in_str: in_str = None
            elif in_str == '`' and ch == '$' and s[k+1] == '{':
                pass
        else:
            if ch in '"\'`': in_str = ch
            elif ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0: return i, k + 1
        k += 1

# ---------- main.js ----------
# M1 standings champions + no-CCG switch (replaces __F24CHAMPS and __F24CONF)
a, b = cut_function(m, '__F24CONF'); m = m[:a] + m[b:]; print('ok M1a old __F24CONF removed')
a, b = cut_function(m, '__F24CHAMPS'); m = m[:a] + src('ccg.js').strip() + '\n' + src('bcs.js').strip() + m[b:]; print('ok M1b __F24CHAMPS + __F24CONF + switch inserted')
# M2 24-team bracket/calendar
a, b = cut_function(m, '__F24'); m = m[:a] + src('f24.js').strip() + m[b:]; print('ok M2 __F24 replaced')
# M3 skip title games when the switch is off (any playoff format); champions + coach credit from standings
m = rep(m, '...(u.playoffFormat===__F24ID?__F24CONF(I,T,o,t):e.map((e=>X.createGame(e,t)))),',
        '...__FCCGQ(u,e,I,T,o,t,h),', 'M3 q block')
# M4 Army-Navy before the first round in the 24-team format
m = rep(m, 'name:"Army-Navy Game",week:c.WEEK_PRE_BOWL,', 'name:"Army-Navy Game",week:u.playoffFormat===__F24ID?c.WEEK_CCG:c.WEEK_PRE_BOWL,', 'M4 Army-Navy week')
# M5 teams map available to the committee from the first week processed
m = rep(m, 'globalThis.__FCONF0=T}catch(z0){globalThis.__FCMG=[]}', 'globalThis.__FCONF0=T,globalThis.__fccdTeams=o}catch(z0){globalThis.__FCMG=[]}', 'M5 teams map')
# M6 committee: standings champions get a smaller bump than title-game winners; keep their 4-loss exemption
m = rep(m, 'const champ=new Set;G.forEach(g=>{"conference-championship"===g.type&&champ.add(g.homeTeamWon?g.homeTeamId:g.awayTeamId)});',
        'const champ=new Set;G.forEach(g=>{"conference-championship"===g.type&&champ.add(g.homeTeamWon?g.homeTeamId:g.awayTeamId)});const champS=new Set,OF0=__FCCGOFF(st),AL0=__FNOCCG(st);if((AL0||OF0.size)&&wk>=13)try{const tm0=globalThis.__fccdTeams;tm0&&Object.entries(__F24CHAMPS(T,CF,tm0)).forEach(([k,b])=>{(AL0||OF0.has(String(k)))&&champS.add(b.id)})}catch(z){}',
        'M6a committee champs')
m = rep(m, '+(champ.has(q.teamId)?.8:0)', '+(champ.has(q.teamId)?.8:champS.has(q.teamId)?.5:0)', 'M6b committee bump')
m = rep(m, 'ch2=q=>!!acc[q.teamId]?.conferenceWinner||champ.has(q.teamId)', 'ch2=q=>!!acc[q.teamId]?.conferenceWinner||champ.has(q.teamId)||champS.has(q.teamId)', 'M6c 4-loss rule')
# M7 awards (Heisman) week follows the 24-team calendar: tallied in week 14 once the 24-team format is live
m = rep(m, 't.AWARDS_WEEK=t.WEEK_PRE_BOWL,t.getSeasonPhaseLabel',
        'Object.defineProperty(t,"AWARDS_WEEK",{get:()=>globalThis.__FAW24F&&globalThis.__FAW24F()?t.WEEK_CCG:t.WEEK_PRE_BOWL,enumerable:!0,configurable:!0}),t.getSeasonPhaseLabel', 'M7 awards getter')
m = rep(m, 'function P(){return C(T())}',
        'function P(){return C(T())}globalThis.__FLS=()=>{try{return P()}catch(z){return null}};globalThis.__FAW24F=()=>{const s=globalThis.__FLS();return!!s&&"24-team-23-plus-1"===s.leagueSettings?.playoffFormat&&(s.mostRecentWeek?.year??0)>(s.startingYear??9999)};',
        'M7b save settings accessor')
# M8 week labels
m = rep(m, 'getWeekTypeLabel=function(e){const t=d(e);return t===a.RegularSeason?`Week ${e}`:f[t]}',
        'getWeekTypeLabel=function(e){const t=d(e);return t===a.RegularSeason?`Week ${e}`:globalThis.__FWKL?globalThis.__FWKL(t,a,f[t]):f[t]}', 'M8a label')
m = rep(m, 'getLabelForWeekType=function(e){return f[e]}', 'getLabelForWeekType=function(e){return globalThis.__FWKL?globalThis.__FWKL(e,a,f[e]):f[e]}', 'M8b label')
WKL_MAIN = ';globalThis.__FWKL=function(t,E,L){try{const s=globalThis.__FLS&&globalThis.__FLS();if(!s)return L;const ls=s.leagueSettings||{},on=(s.mostRecentWeek?.year??0)>(s.startingYear??9999),f24="24-team-23-plus-1"===ls.playoffFormat&&on;if(f24&&t===E.ConfChampWeek)return"Army-Navy & Awards";if(f24&&t===E.PreBowlWeek)return"CFP First Round";if(("fccd-no-ccg"===ls.ccgUseHighestRanked||f24)&&t===E.ConfChampWeek)return"Open Week (no CCGs)";return L}catch(z){return L}};'
# M9 conference schedules: home/road streak limit
m = rep(m, '  return games;\n}\nglobalThis.__fccdConfSched=__fccdConfSched;',
        '  // v3.14: no more than 2 conference home (or road) games in a row; traditional dates stay pinned\n'
        '  if (typeof globalThis !== "undefined" && globalThis.__fccdHAFix) globalThis.__fccdHAFix(games, weeks, confKey + "|ha|" + year, function (g) { var a = idx[g.homeTeamId], b = idx[g.awayTeamId]; if (a === undefined || b === undefined) return true; var c = fixedMap[key(a, b)]; return c !== undefined && weekOf[c] === g.week; });\n'
        '  return games;\n}\nglobalThis.__fccdConfSched=__fccdConfSched;\n' + src('hafix.js').strip() + '\n', 'M9 conf scheduler')
m = rep(m, 'if(1===e.divisions.length)return(0,n.default)(e.divisions[0],t,a);if(2===e.divisions.length)return(0,l.default)(e.divisions[0],e.divisions[1],t,a);if(4===e.divisions.length)return(0,s.default)(e.divisions[0],e.divisions[1],e.divisions[2],e.divisions[3],t,a);',
        'const HW0=g=>{try{return 1===e.divisions.length&&10!==e.divisions[0].teamDivisionYears.length||!globalThis.__fccdHAFix?g:globalThis.__fccdHAFix(g,t,e.id+"|ha|"+a,null)}catch(z){return g}};if(1===e.divisions.length)return HW0((0,n.default)(e.divisions[0],t,a));if(2===e.divisions.length)return HW0((0,l.default)(e.divisions[0],e.divisions[1],t,a));if(4===e.divisions.length)return HW0((0,s.default)(e.divisions[0],e.divisions[1],e.divisions[2],e.divisions[3],t,a));',
        'M10 stock schedulers')
# M11 BCS mode in the weekly poll
m = rep(m, '__FCOMMITTEE(e,s,n),__FAPPOLL(e,a,i,s),nl(e)}', '__FBCSON(n)?__FBCS(e,a,i,s,n):(__FCOMMITTEE(e,s,n),__FAPPOLL(e,a,i,s)),nl(e)}', 'M11 BCS hook')
m = rep(m, 'function __FAPPOLL(e,pr0,res,wk){try{if(wk<0||wk>8)return;', 'function __FAPPOLL(e,pr0,res,wk,fx){try{if(wk<0||wk>8&&!fx)return;', 'M12a AP poll all season (BCS human poll)')
m = rep(m, 'ord.slice().forEach(id=>{if(PS(id)>10||L(id)>1)return;', 'wk<=8&&ord.slice().forEach(id=>{if(PS(id)>10||L(id)>1)return;', 'M12b pedigree through week 8 only')
m = rep(m, 'try{if(a>=9&&a<=c.WEEK_CCG){const top=[...RK.entries()]', 'try{if(__FBCSON(l?.leagueSettings))__FBCSNEWS(t,a,nm,rec);else if(a>=9&&a<=c.WEEK_CCG){const top=[...RK.entries()]', 'M13 BCS newspaper')
m = WKL_MAIN + m

# ---------- renderer.js ----------
FLAGS = ';globalThis.__FFLAGS=function(s){try{const ls=s&&s.leagueSettings||{},on=(s&&s.mostRecentWeek&&s.mostRecentWeek.year||0)>(s&&s.startingYear||9999);globalThis.__FAW24="24-team-23-plus-1"===ls.playoffFormat&&on;globalThis.__FNOCCGR="fccd-no-ccg"===ls.ccgUseHighestRanked||globalThis.__FAW24;const hg=ls.ccgHomeGames||{};globalThis.__FOFFC=Object.keys(hg).filter(k=>"none"===hg[k])}catch(z){}};' \
        'globalThis.__FWKL=function(t,E,L){try{if(globalThis.__FAW24&&t===E.ConfChampWeek)return"Army-Navy & Awards";if(globalThis.__FAW24&&t===E.PreBowlWeek)return"CFP First Round";if(globalThis.__FNOCCGR&&t===E.ConfChampWeek)return"Open Week (no CCGs)";return L}catch(z){return L}};'
r = rep(r, 'setSaveInfo:(t,e)=>e.payload,', 'setSaveInfo:(t,e)=>(globalThis.__FFLAGS&&globalThis.__FFLAGS(e.payload),e.payload),', 'R1 setSaveInfo')
SNAP = 'globalThis.__FFLAGS&&globalThis.__FFLAGS({leagueSettings:{playoffFormat:t.leagueSettings.playoffFormat,ccgUseHighestRanked:t.leagueSettings.ccgUseHighestRanked,ccgHomeGames:{...t.leagueSettings.ccgHomeGames}},startingYear:t.startingYear,mostRecentWeek:{year:t.mostRecentWeek.year}})'
r = rep(r, 'updateMostRecentWeek:(t,e)=>{t.mostRecentWeek.year=e.payload.year,t.mostRecentWeek.week=e.payload.week}',
        'updateMostRecentWeek:(t,e)=>{t.mostRecentWeek.year=e.payload.year,t.mostRecentWeek.week=e.payload.week;' + SNAP + '}', 'R2 week')
r = rep(r, 'setLeagueSettings:(t,e)=>{t.leagueSettings={...t.leagueSettings,...e.payload.newSettings}}',
        'setLeagueSettings:(t,e)=>{t.leagueSettings={...t.leagueSettings,...e.payload.newSettings};' + SNAP + '}', 'R3 settings')
r = rep(r, 'e.AWARDS_WEEK=e.WEEK_PRE_BOWL,e.getSeasonPhaseLabel',
        'Object.defineProperty(e,"AWARDS_WEEK",{get:()=>globalThis.__FAW24?e.WEEK_CCG:e.WEEK_PRE_BOWL,enumerable:!0,configurable:!0}),e.getSeasonPhaseLabel', 'R4 awards getter')
r = rep(r, 's!==ei.WEEK_CCG+1?s!==ei.AWARDS_WEEK+1?', 's!==ei.WEEK_CCG+1||s===ei.AWARDS_WEEK+1?s!==ei.AWARDS_WEEK+1?', 'R5 auto dialog')
r = rep(r, 's===ei.WEEK_CCG+1?C(!0):s===ei.AWARDS_WEEK+1?b(!0):A(!0)', 's===ei.AWARDS_WEEK+1?b(!0):s===ei.WEEK_CCG+1?C(!0):A(!0)', 'R6 dialog button')
r = rep(r, 'if(t===ei.WEEK_PRE_CCG){if(o.some(', 'if(t===ei.WEEK_PRE_CCG&&!globalThis.__FNOCCGR){if(o.some(', 'R7 CCG invite banner')
r = rep(r, 'getWeekTypeLabel=function(t){const e=p(t);return e===i.RegularSeason?`Week ${t}`:h[e]}',
        'getWeekTypeLabel=function(t){const e=p(t);return e===i.RegularSeason?`Week ${t}`:globalThis.__FWKL?globalThis.__FWKL(e,i,h[e]):h[e]}', 'R8a label')
r = rep(r, 'getLabelForWeekType=function(t){return h[t]}', 'getLabelForWeekType=function(t){return globalThis.__FWKL?globalThis.__FWKL(t,i,h[t]):h[t]}', 'R8b label')
NOCCG_OPT = ',{value:"fccd-no-ccg",label:"No conference title games",secondaryLabel:"No conference championship games. Champions come from the standings: best conference record, then head-to-head among tied teams (if they all played each other), record against common conference opponents, then the committee ranking. The champion still gets the title, its automatic playoff bid and its coach\'s championship credit. Notre Dame is never ACC champion. Always on with the 24-team playoff."}'
r = rep(r, 'secondaryLabel:`The top two teams in each conference ${E}`}];', 'secondaryLabel:`The top two teams in each conference ${E}`}' + NOCCG_OPT + '];', 'R9 CCG dropdown')
r = rep(r, 'label:"24 team (23 at-large + top G6 champ)",secondaryLabel:"The 23 highest-ranked teams plus the top Group of 6 champion. Top 8 seeds get byes; seeds 9-16 host 17-24 on campus; no conference title games. A dynasty\'s first season still uses the 12-team format."',
        'label:"24 team (5 auto bids + 19 at-large)",secondaryLabel:"The 4 Power 4 champions and the best-ranked Group of 6 champion get automatic bids; 19 at-large teams by ranking. Seeded 1-24 by ranking; top 8 get byes; first and second rounds on campus. No conference title games; Army-Navy and the Heisman come before the first round. A dynasty\'s first season still uses the 12-team format."', 'R10 24 label')
r = rep(r, '"24-team-23-plus-1":"24 team playoff (23 at-large + top Group of 6 champion), top 8 seeds receive byes"',
        '"24-team-23-plus-1":"24 team playoff (4 Power 4 champions + top Group of 6 champion + 19 at-large), top 8 seeds receive byes"', 'R11 bracket text')
r = rep(r, 't.leagueSettings.ccgConferenceIdDomes=e.payload.ccgConferenceIdDomes}}}),', 't.leagueSettings.ccgConferenceIdDomes=e.payload.ccgConferenceIdDomes;' + SNAP + '}}}),', 'R12 postseason locations flags')
r = rep(r, 'if(t===ei.WEEK_PRE_CCG&&!globalThis.__FNOCCGR){', 'if(t===ei.WEEK_PRE_CCG&&!globalThis.__FNOCCGR&&!(globalThis.__FOFFC||[]).includes(String(i.getCurrentConferenceForTeam(e.id)?.id))){', 'R13 banner per conference')
r = rep(r, 'function WO({conference:t,isCcgHomeGame:e,isCcgInDome:i,onChange:o}){const a=function(t,e){', 'function WO({conference:t,isCcgHomeGame:e,isCcgInDome:i,onChange:o}){const a="none"===e?"no-ccg":function(t,e){', 'R14a per-conf value')
r = rep(r, 'switch(t){case HO.NeutralOutdoors:return[!1,!1];', 'switch(t){case"no-ccg":return["none",!1];case HO.NeutralOutdoors:return[!1,!1];', 'R14b per-conf choice')
r = rep(r, 'const YO=[{value:HO.HomeGame,label:"Home game"},{value:HO.NeutralOutdoors,label:"Neutral (outdoors)"},{value:HO.NeutralIndoors,label:"Neutral (indoors)"}];', 'const YO=[{value:HO.HomeGame,label:"Home game"},{value:HO.NeutralOutdoors,label:"Neutral (outdoors)"},{value:HO.NeutralIndoors,label:"Neutral (indoors)"},{value:"no-ccg",label:"No title game"}];', 'R14c per-conf option')
r = rep(r, 'CCGs can be played at the home stadium of the higher-seeded team, or at a neutral site, which can be indoors or outdoors.', 'CCGs can be played at the home stadium of the higher-seeded team, or at a neutral site, which can be indoors or outdoors. Choose No title game to crown that conference champion from the standings instead.', 'R14d help text')
BCS_UI = ',(0,n.jsx)(O,{label:"BCS rankings",value:t.fccdBcs??"off",onValue:"on",offValue:"off",onTooltip:"Throwback mode: from week 8 the official ranking is the BCS standings (Harris poll + Coaches poll + average of six win-loss computer rankings, highest and lowest dropped). It picks and seeds the field in any playoff format; pair it with Single game (no playoff) for #1 vs #2.",offTooltip:"Rankings follow the CFP selection committee (from week 9).",onChange:i=>e?.({...t,fccdBcs:i}),disabled:!e},void 0)'
r = rep(r, 'onChange:i=>e?.({...t,ccgUseHighestRanked:i}),disabled:!e},void 0)', 'onChange:i=>e?.({...t,ccgUseHighestRanked:i}),disabled:!e},void 0)' + BCS_UI, 'R15 BCS toggle')
r = FLAGS + r

open(MAIN, 'w', encoding='utf-8').write(m)
open(REND, 'w', encoding='utf-8').write(r)
print('main', len(m.encode()), 'renderer', len(r.encode()))
