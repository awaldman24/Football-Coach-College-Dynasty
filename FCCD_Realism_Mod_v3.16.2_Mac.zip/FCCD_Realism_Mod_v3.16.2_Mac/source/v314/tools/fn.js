// usage: node fn.js main.js name1 name2 ... -> prints source of top-level-ish function declarations with these names
const fs=require('fs'),acorn=require('acorn'),walk=require('acorn-walk');
const src=fs.readFileSync(process.argv[2],'utf8');
const names=new Set(process.argv.slice(3));
const ast=acorn.parse(src,{ecmaVersion:'latest',sourceType:'script',allowHashBang:true});
walk.full(ast,n=>{if((n.type==='FunctionDeclaration')&&n.id&&names.has(n.id.name)){console.log('//== '+n.id.name+' @'+n.start+'-'+n.end);console.log(src.slice(n.start,n.end));}});
