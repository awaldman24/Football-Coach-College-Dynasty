// node freevars.js file fnName... : lists identifiers used in each function that are not declared in it or any enclosing scope
const fs=require('fs'),acorn=require('acorn'),walk=require('acorn-walk');
const src=fs.readFileSync(process.argv[2],'utf8');const targets=new Set(process.argv.slice(3));
const ast=acorn.parse(src,{ecmaVersion:'latest'});
const GLOBALS=new Set('globalThis Math Object Set Map console JSON Array Number String Error Infinity undefined Promise Date isNaN parseInt parseFloat Symbol RegExp Boolean require process setTimeout'.split(' '));
function pat(p,out){if(!p)return;if(p.type==='Identifier')out.add(p.name);else if(p.type==='ObjectPattern')p.properties.forEach(q=>pat(q.value||q.argument,out));else if(p.type==='ArrayPattern')p.elements.forEach(e=>pat(e,out));else if(p.type==='RestElement')pat(p.argument,out);else if(p.type==='AssignmentPattern')pat(p.left,out)}
function declsIn(fn){const out=new Set();if(fn.id&&fn.type!=='FunctionDeclaration')out.add(fn.id.name);fn.params&&fn.params.forEach(p=>pat(p,out));
  const v=n=>{if(!n||typeof n!=='object')return;if(Array.isArray(n))return n.forEach(v);
    if(n.type==='FunctionDeclaration'){out.add(n.id.name);return}if(n!==fn&&/Function/.test(n.type))return;
    if(n.type==='VariableDeclaration')n.declarations.forEach(d=>pat(d.id,out));if(n.type==='CatchClause')pat(n.param,out);if(n.type==='ClassDeclaration'&&n.id)out.add(n.id.name);
    for(const k in n){if(k==='type')continue;const x=n[k];if(x&&typeof x==='object')v(x)}};v(fn.body);return out}
// collect chain for each target
function search(n,stack){if(!n||typeof n!=='object')return;if(Array.isArray(n))return n.forEach(x=>search(x,stack));
  if(n.type==='FunctionDeclaration'&&n.id&&targets.has(n.id.name))check(n,stack);
  const isF=/Function/.test(n.type);if(isF)stack.push(n);for(const k in n){if(k==='type')continue;const x=n[k];if(x&&typeof x==='object')search(x,stack)}if(isF)stack.pop()}
const top=new Set();const tv=n=>{};(function(){const fake={type:'FunctionExpression',params:[],body:{type:'BlockStatement',body:ast.body}};declsIn(fake).forEach(x=>top.add(x))})();
function check(fn,stack){const env=new Set(top);stack.forEach(f=>declsIn(f).forEach(x=>env.add(x)));
  const missing=new Set();
  // walk fn including nested functions, tracking their local decls
  const rec=(n,local)=>{if(!n||typeof n!=='object')return;if(Array.isArray(n))return n.forEach(x=>rec(x,local));
    if(/Function/.test(n.type)){const l2=new Set(local);declsIn(n).forEach(x=>l2.add(x));if(n.type==='FunctionDeclaration')local.add(n.id.name);rec(n.body,l2);return}
    if(n.type==='MemberExpression'){rec(n.object,local);if(n.computed)rec(n.property,local);return}
    if(n.type==='Property'){if(n.computed)rec(n.key,local);rec(n.value,local);return}
    if(n.type==='Identifier'){if(!local.has(n.name)&&!env.has(n.name)&&!GLOBALS.has(n.name))missing.add(n.name);return}
    if(n.type==='LabeledStatement'||n.type==='BreakStatement'||n.type==='ContinueStatement'){if(n.body)rec(n.body,local);return}
    for(const k in n){if(k==='type'||k==='start'||k==='end')continue;const x=n[k];if(x&&typeof x==='object')rec(x,local)}};
  const local=declsIn(fn);local.add(fn.id.name);rec(fn.body,local);
  console.log(fn.id.name.padEnd(16),missing.size?'UNRESOLVED: '+[...missing].join(','):'all names resolve')}
search(ast,[]);
