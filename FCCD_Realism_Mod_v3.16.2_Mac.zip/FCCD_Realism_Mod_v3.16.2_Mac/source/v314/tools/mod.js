// print webpack module factory source by id: node mod.js main.js id...
const fs=require('fs'),acorn=require('acorn'),walk=require('acorn-walk');
const src=fs.readFileSync(process.argv[2],'utf8');const ids=new Set(process.argv.slice(3));
const ast=acorn.parse(src,{ecmaVersion:'latest'});const out={};
walk.full(ast,n=>{if(n.type==='Property'&&n.key&&(n.key.type==='Literal')&&ids.has(String(n.key.value))&&!out[n.key.value]){out[n.key.value]=src.slice(n.value.start,n.value.end)}});
console.log(JSON.stringify(out));
